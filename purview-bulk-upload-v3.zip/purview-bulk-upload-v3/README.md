# Purview Bulk Upload — Multi-Operation, Multi-API Edition

Python Azure Function that runs any Purview bulk-upload operation across **both** Purview REST API surfaces:

- **Atlas Data Map API** (`/api/atlas/v2/...`) for technical metadata
- **Unified Catalog API** (`/datagovernance/catalog/...`, public preview since Oct 2025) for business governance

One HTTP endpoint, one Excel-template-in-blob convention, two clients under the hood.

## Operations included

### Atlas Data Map (PyApacheAtlas)

| Operation | Purpose | RBAC needed |
|---|---|---|
| `asset_description` | Update entity descriptions, owners, custom attrs | Data Curator |
| `classification` | Attach classifications to entities | Data Curator |
| `label` | Attach free-form labels to entities | Data Curator |

### Unified Catalog (direct REST)

| Operation | Purpose | RBAC needed |
|---|---|---|
| `governance_domain` | Create governance / business domains | Governance domain creator |
| `critical_data_element` | Create CDEs within a domain | Data Steward on domain |
| `cde_mapping` | Map CDEs to columns / entities | Data Steward on domain |
| `uc_data_product` | Create UC-native data products | Data Product Owner |

> The Unified Catalog API is in **public preview** (`api-version=2025-09-15-preview`). Microsoft has noted that data asset and critical data column APIs for UC are on the roadmap — the `cde_mapping` handler uses the `relationships` endpoint that's available today; update it when the dedicated mapping API ships.

## How to use

```bash
# Same endpoint, different operation
curl -X POST ".../api/bulk-upload?operation=governance_domain" -H "x-functions-key: $K"
curl -X POST ".../api/bulk-upload?operation=critical_data_element" -H "x-functions-key: $K"
curl -X POST ".../api/bulk-upload?operation=asset_description" -H "x-functions-key: $K"

# Discover what's available
curl .../api/operations
# Returns:
#   {"operations": [
#     {"operation": "asset_description", "api_surface": "atlas", ...},
#     {"operation": "governance_domain", "api_surface": "uc", ...},
#     ...
#   ]}
```

## Project layout

```
purview-bulk-upload/
├── function_app.py
├── clients/                              # ⭐ One per API surface
│   ├── base.py                           #     PurviewClientBase contract
│   ├── atlas_client.py                   #     PyApacheAtlas wrapper
│   └── unified_catalog_client.py         #     Direct REST + AAD token cache
├── handlers/
│   ├── base.py                           #     Adds client_type to contract
│   ├── asset_description.py              #     atlas
│   ├── classification.py                 #     atlas
│   ├── label.py                          #     atlas
│   ├── governance_domain.py              #     uc
│   ├── critical_data_element.py          #     uc
│   ├── cde_mapping.py                    #     uc
│   └── uc_data_product.py                #     uc
├── services/
│   ├── blob_client.py
│   ├── excel_reader.py                   #     handler-driven schema
│   └── purview_client.py                 #     ⭐ Picks client per handler
├── templates/                            #     7 templates, blue=atlas, purple=uc
└── ...
```

## Adding a new bulk operation

1. Decide which API surface it lives on
2. Create `handlers/my_op.py` extending `BulkOperationHandler` — set `client_type` to `"atlas"` or `"uc"`
3. Implement `parse_row`, `validate` (optional), `execute_batch`
4. Register in `handlers/__init__.py` — one line
5. Drop an Excel template in the blob container

The dispatcher, executor, Excel reader, and pipeline are operation-agnostic and surface-agnostic.

## Example: handler skeleton for a UC operation

```python
from dataclasses import dataclass
from .base import BulkOperationHandler

@dataclass
class OKRRecord:
    name: str
    domain_name: str
    target_value: float
    row_number: int = 0


class OKRHandler(BulkOperationHandler):

    @property
    def operation_name(self): return "okr"

    @property
    def client_type(self): return "uc"   # ← picks UnifiedCatalogClient automatically

    @property
    def required_columns(self): return {"name", "domain_name", "target_value"}

    @property
    def default_sheet(self): return "OKRs"

    @property
    def batch_size(self): return 1

    def parse_row(self, row_data, row_number):
        return OKRRecord(
            name=row_data["name"],
            domain_name=row_data["domain_name"],
            target_value=float(row_data["target_value"]),
            row_number=row_number,
        )

    def execute_batch(self, batch, client):  # client is UnifiedCatalogClient
        for rec in batch:
            client.post("okrs", json={
                "name": rec.name,
                "domain": self._lookup_domain_id(client, rec.domain_name),
                "targetValue": rec.target_value,
            })
        return {"succeeded": len(batch), "failed": 0, "errors": []}
```

That's it — no changes to the function app, executor, or pipeline.

## Azure setup

### 1. Function App (already created)
- Linux + Python 3.10
- System-assigned Managed Identity enabled
- App settings:
  - `PURVIEW_ACCOUNT_NAME` — your Purview account
  - `STORAGE_ACCOUNT_NAME` — your storage account
  - `BLOB_CONTAINER_NAME` — container holding templates

### 2. Storage Account RBAC
Grant the Function App's Managed Identity:
- `Storage Blob Data Reader` on the templates container

### 3. Purview RBAC (this is where v3 differs)

**For Atlas operations** (`asset_description`, `classification`, `label`):
- In Purview portal → Data Map → Collections → Root → Role assignments
- Add the Managed Identity as `Data Curator`

**For Unified Catalog operations**, the Managed Identity needs governance-plane roles assigned at the governance domain level:
- `Governance domain creator` (tenant-level) — for `governance_domain` op
- `Data Steward` on the target domain — for `critical_data_element`, `cde_mapping`
- `Data Product Owner` on the target domain — for `uc_data_product`
- `Data Catalog Reader` everywhere — for lookups (parent domain, CDE-by-name, etc.)

If you'll run all UC operations, the simplest config is:
- `Governance domain creator` at the tenant level
- `Governance domain owner` on every domain the function will touch (this implies Steward + Product Owner)

### 4. Upload templates
Upload all 7 `*-template.xlsx` files from `templates/` to your blob container.

### 5. ADO pipeline variables
Variable group `purview-bulk-upload-vars`:
- `azureSubscription` — ADO service connection name
- `functionAppName` — your function app
- `resourceGroupName` — its RG

## Pipeline flow

The pipeline takes an `operation` parameter when queued:

```
build → deploy → smoke (/health) → trigger ?operation=<selected>
```

`skip_trigger` deploys without firing an upload. To run multiple operations in one pipeline run, queue once per operation, or extend the trigger stage with a matrix loop.

## Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| `POST` | `/api/bulk-upload?operation=<name>` | Function key | Run one bulk operation |
| `GET`  | `/api/operations` | Anonymous | List registered ops + their API surface and schema |
| `GET`  | `/api/health` | Anonymous | Smoke check |

## API surface summary

| | Atlas Data Map | Unified Catalog |
|---|---|---|
| Base path | `/api/atlas/v2/` | `/datagovernance/catalog/` |
| Audience | `https://purview.azure.net` | `https://purview.azure.net` |
| API version | (stable) | `2025-09-15-preview` |
| SDK | PyApacheAtlas | None — direct HTTP |
| Bulk endpoints | Yes (`entity/bulk`) | No — one POST per record |
| RBAC at | Collection level (Data Map) | Domain level (governance) |

Same Purview account, same AAD audience, different paths and different RBAC models. The dual-client architecture handles all of that for you.
