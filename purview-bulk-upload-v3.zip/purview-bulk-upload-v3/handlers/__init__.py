"""
Operation registry — single source of truth for available bulk operations.

To add a new operation:
    1. Create handlers/my_new_op.py with a BulkOperationHandler subclass
    2. Set client_type to "atlas" or "uc"
    3. Add ONE line to _HANDLERS below
    4. Drop a template Excel into the blob container
"""
from .asset_description import AssetDescriptionHandler
from .base import BulkOperationHandler
from .cde_mapping import CDEMappingHandler
from .classification import ClassificationHandler
from .critical_data_element import CriticalDataElementHandler
from .governance_domain import GovernanceDomainHandler
from .label import LabelHandler
from .uc_data_product import UCDataProductHandler


# ============== REGISTER NEW HANDLERS HERE ==============
_HANDLERS: dict[str, type[BulkOperationHandler]] = {
    # ---- Atlas Data Map operations ----
    "asset_description":      AssetDescriptionHandler,
    "classification":         ClassificationHandler,
    "label":                  LabelHandler,

    # ---- Unified Catalog operations ----
    "governance_domain":      GovernanceDomainHandler,
    "critical_data_element":  CriticalDataElementHandler,
    "cde_mapping":            CDEMappingHandler,
    "uc_data_product":        UCDataProductHandler,

    # Future:
    # "uc_glossary_term":     UCGlossaryTermHandler,
    # "okr":                  OKRHandler,
    # "data_access_policy":   DataAccessPolicyHandler,
}
# =========================================================


def get_handler(operation_name: str) -> BulkOperationHandler:
    if operation_name not in _HANDLERS:
        available = sorted(_HANDLERS.keys())
        raise ValueError(
            f"Unknown operation '{operation_name}'. Available: {available}"
        )
    return _HANDLERS[operation_name]()


def list_operations() -> list[dict]:
    out = []
    for name, handler_cls in _HANDLERS.items():
        h = handler_cls()
        out.append({
            "operation": name,
            "api_surface": h.client_type,
            "required_columns": sorted(h.required_columns),
            "optional_columns": sorted(h.optional_columns),
            "default_template": h.default_template,
            "default_sheet": h.default_sheet,
        })
    return out


__all__ = ["BulkOperationHandler", "get_handler", "list_operations"]
