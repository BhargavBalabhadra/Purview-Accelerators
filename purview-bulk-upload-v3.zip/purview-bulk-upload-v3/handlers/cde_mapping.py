"""
Bulk-map Critical Data Elements to data columns / assets.
Operation: ?operation=cde_mapping
API: POST /datagovernance/catalog/criticalDataElements/{cdeId}/relationships

This creates relationships between a CDE and entities (typically critical
data columns from the Data Map). The columns themselves must already exist
in Purview as scanned entities.

NOTE: As of the 2025-09-15-preview API, "Data asset and critical data column
APIs for Unified Catalog are on our roadmap" per Microsoft docs. This handler
uses the available relationships endpoint and the CRITICALDATACOLUMN entity
type. Update when the dedicated mapping API ships.

Required RBAC: 'Data Steward' role on the CDE's governance domain.

Excel columns:
    cde_name        (required) — CDE name to map FROM
    domain_name     (required) — governance domain containing the CDE
    entity_id       (required) — target entity GUID (the column/asset)
    entity_type     (optional) — default: CRITICALDATACOLUMN
    relationship    (optional) — default: Related
    description     (optional)
"""
import logging
from dataclasses import dataclass
from typing import Optional

from .base import BulkOperationHandler


@dataclass
class CDEMappingRecord:
    cde_name: str
    domain_name: str
    entity_id: str
    entity_type: str = "CRITICALDATACOLUMN"
    relationship: str = "Related"
    description: str = ""
    row_number: int = 0


class CDEMappingHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "cde_mapping"

    @property
    def client_type(self) -> str:
        return "uc"

    @property
    def required_columns(self) -> set[str]:
        return {"cde_name", "domain_name", "entity_id"}

    @property
    def optional_columns(self) -> set[str]:
        return {"entity_type", "relationship", "description"}

    @property
    def default_sheet(self) -> str:
        return "CDEMappings"

    @property
    def batch_size(self) -> int:
        return 1

    def parse_row(self, row_data: dict, row_number: int) -> CDEMappingRecord:
        return CDEMappingRecord(
            cde_name=row_data["cde_name"],
            domain_name=row_data["domain_name"],
            entity_id=row_data["entity_id"],
            entity_type=row_data.get("entity_type") or "CRITICALDATACOLUMN",
            relationship=row_data.get("relationship") or "Related",
            description=row_data.get("description") or "",
            row_number=row_number,
        )

    def execute_batch(self, batch: list[CDEMappingRecord], client) -> dict:
        """client is a UnifiedCatalogClient."""
        succeeded = 0
        failed = 0
        errors = []

        cde_cache: dict[tuple, str] = {}  # (domain_name, cde_name) -> cde_id

        for rec in batch:
            try:
                key = (rec.domain_name, rec.cde_name)
                cde_id = cde_cache.get(key)
                if not cde_id:
                    cde_id = self._lookup_cde_id(
                        client, rec.cde_name, rec.domain_name
                    )
                    if not cde_id:
                        raise ValueError(
                            f"CDE '{rec.cde_name}' not found in domain "
                            f"'{rec.domain_name}'"
                        )
                    cde_cache[key] = cde_id

                payload = {
                    "entityId": rec.entity_id,
                    "relationshipType": rec.relationship,
                    "description": rec.description,
                }
                client.post(
                    f"criticalDataElements/{cde_id}/relationships",
                    json=payload,
                    params={"entityType": rec.entity_type},
                )
                logging.info(
                    f"Mapped CDE '{rec.cde_name}' -> entity {rec.entity_id}"
                )
                succeeded += 1
            except Exception as e:
                logging.error(
                    f"Failed CDE mapping {rec.cde_name} -> {rec.entity_id}: {e}"
                )
                failed += 1
                errors.append(
                    f"row {rec.row_number} ({rec.cde_name} -> {rec.entity_id}): {e}"
                )

        return {"succeeded": succeeded, "failed": failed, "errors": errors}

    @staticmethod
    def _lookup_cde_id(client, cde_name: str, domain_name: str) -> Optional[str]:
        """
        Find the CDE id by name within a specific domain.
        Resolves domain name to id first, then searches CDEs scoped to that domain.
        """
        # 1. Resolve domain
        domain_result = client.get(
            "businessdomains", params={"keyword": domain_name, "top": 50}
        )
        domain_id = None
        for d in domain_result.get("value", []):
            if d.get("name") == domain_name:
                domain_id = d.get("id")
                break
        if not domain_id:
            return None

        # 2. Search CDEs in that domain
        cde_result = client.get(
            "criticalDataElements",
            params={"domainId": domain_id, "keyword": cde_name, "top": 50},
        )
        for cde in cde_result.get("value", []):
            if cde.get("name") == cde_name:
                return cde.get("id")
        return None
