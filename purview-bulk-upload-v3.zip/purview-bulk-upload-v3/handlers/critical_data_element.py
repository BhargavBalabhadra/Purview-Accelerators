"""
Bulk-create Critical Data Elements in Purview Unified Catalog.
Operation: ?operation=critical_data_element
API: POST /datagovernance/catalog/criticalDataElements

Required RBAC: 'Data Steward' role on the target governance domain.

CDEs are logical groupings of important data concepts (e.g. "Customer ID"
mapping CustID, CID, Customer_Number from multiple tables) within a
governance domain. This handler creates the CDE. Mapping CDEs to actual
columns (data_assets/columns) requires the `cde_mapping` handler.

Excel columns:
    name         (required) — CDE name, e.g. "Customer ID"
    domain_name  (required) — name of the governance domain that owns it
    description  (required)
    data_type    (required) — TEXT | NUMBER | DATE | BOOLEAN
    status       (optional) — DRAFT | PUBLISHED (default: DRAFT)
    owner        (optional) — AAD object id of the owner
"""
import logging
from dataclasses import dataclass
from typing import Optional

from .base import BulkOperationHandler


VALID_DATA_TYPES = {"TEXT", "NUMBER", "DATE", "BOOLEAN"}
VALID_STATUSES = {"DRAFT", "PUBLISHED"}


@dataclass
class CDERecord:
    name: str
    domain_name: str
    description: str
    data_type: str
    status: str = "DRAFT"
    owner: Optional[str] = None
    row_number: int = 0


class CriticalDataElementHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "critical_data_element"

    @property
    def client_type(self) -> str:
        return "uc"

    @property
    def required_columns(self) -> set[str]:
        return {"name", "domain_name", "description", "data_type"}

    @property
    def optional_columns(self) -> set[str]:
        return {"status", "owner"}

    @property
    def default_sheet(self) -> str:
        return "CriticalDataElements"

    @property
    def batch_size(self) -> int:
        return 1

    def parse_row(self, row_data: dict, row_number: int) -> CDERecord:
        return CDERecord(
            name=row_data["name"],
            domain_name=row_data["domain_name"],
            description=row_data["description"],
            data_type=row_data["data_type"].upper(),
            status=(row_data.get("status") or "DRAFT").upper(),
            owner=row_data.get("owner") or None,
            row_number=row_number,
        )

    def validate(self, record: CDERecord) -> list[str]:
        errs = []
        if record.data_type not in VALID_DATA_TYPES:
            errs.append(
                f"data_type must be one of {sorted(VALID_DATA_TYPES)}, "
                f"got '{record.data_type}'"
            )
        if record.status not in VALID_STATUSES:
            errs.append(
                f"status must be one of {sorted(VALID_STATUSES)}"
            )
        if len(record.name) > 256:
            errs.append("name max length is 256 chars")
        if len(record.description) > 10000:
            errs.append("description max length is 10000 chars")
        return errs

    def execute_batch(self, batch: list[CDERecord], client) -> dict:
        """client is a UnifiedCatalogClient."""
        succeeded = 0
        failed = 0
        errors = []

        # Resolve domain names → ids once per batch
        domain_cache: dict[str, str] = {}

        for rec in batch:
            try:
                domain_id = domain_cache.get(rec.domain_name)
                if not domain_id:
                    domain_id = self._lookup_domain_id(client, rec.domain_name)
                    if not domain_id:
                        raise ValueError(
                            f"Governance domain '{rec.domain_name}' not found. "
                            "Create it first via the governance_domain operation."
                        )
                    domain_cache[rec.domain_name] = domain_id

                payload = {
                    "name": rec.name,
                    "description": rec.description,
                    "domain": domain_id,
                    "dataType": rec.data_type,
                    "status": rec.status,
                }
                if rec.owner:
                    payload["contacts"] = {
                        "Owner": [{"id": rec.owner, "description": ""}],
                    }

                client.post("criticalDataElements", json=payload)
                logging.info(f"Created CDE '{rec.name}' in domain '{rec.domain_name}'")
                succeeded += 1
            except Exception as e:
                logging.error(f"Failed to create CDE '{rec.name}': {e}")
                failed += 1
                errors.append(f"row {rec.row_number} ({rec.name}): {e}")

        return {"succeeded": succeeded, "failed": failed, "errors": errors}

    @staticmethod
    def _lookup_domain_id(client, name: str) -> Optional[str]:
        result = client.get("businessdomains", params={"keyword": name, "top": 50})
        for domain in result.get("value", []):
            if domain.get("name") == name:
                return domain.get("id")
        return None
