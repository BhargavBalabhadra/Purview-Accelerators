"""
Bulk-attach classifications to existing Purview entities.
Operation: ?operation=classification

Excel columns:
    qualified_name   (required) — entity to classify
    asset_type       (required) — needed to look up the entity GUID
    classifications  (required) — comma-separated, e.g. "MICROSOFT.PERSONAL.EMAIL,SOX"
"""
import logging
from dataclasses import dataclass, field

from .base import BulkOperationHandler


@dataclass
class ClassificationRecord:
    qualified_name: str
    asset_type: str
    classifications: list[str] = field(default_factory=list)
    row_number: int = 0


class ClassificationHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "classification"

    @property
    def client_type(self) -> str:
        return "atlas"

    @property
    def required_columns(self) -> set[str]:
        return {"qualified_name", "asset_type", "classifications"}

    @property
    def default_sheet(self) -> str:
        return "Classifications"

    def parse_row(self, row_data: dict, row_number: int) -> ClassificationRecord:
        raw = row_data.get("classifications", "")
        cls_list = [c.strip() for c in str(raw).split(",") if c.strip()]
        return ClassificationRecord(
            qualified_name=row_data["qualified_name"],
            asset_type=row_data["asset_type"],
            classifications=cls_list,
            row_number=row_number,
        )

    def validate(self, record: ClassificationRecord) -> list[str]:
        if not record.classifications:
            return ["At least one classification is required"]
        return []

    def execute_batch(self, batch: list[ClassificationRecord], client) -> dict:
        """client is an AtlasClient."""
        succeeded = 0
        failed = 0
        errors = []

        for rec in batch:
            try:
                client.pyapacheatlas.classify_entity(
                    entityType=rec.asset_type,
                    qualifiedName=rec.qualified_name,
                    classifications=rec.classifications,
                    force_update=True,
                )
                succeeded += 1
            except Exception as e:
                logging.error(
                    f"Classification failed for {rec.qualified_name}: {e}"
                )
                failed += 1
                errors.append(f"row {rec.row_number}: {e}")
        return {"succeeded": succeeded, "failed": failed, "errors": errors}
