"""
Bulk-upload asset descriptions, owners, and custom attributes.
Operation: ?operation=asset_description
"""
import logging
from dataclasses import dataclass

from pyapacheatlas.core import AtlasEntity
from pyapacheatlas.core.util import GuidTracker

from .base import BulkOperationHandler


@dataclass
class AssetDescriptionRecord:
    qualified_name: str
    asset_type: str
    display_name: str
    description: str = ""
    owner: str = ""
    custom_attrs: dict = None
    row_number: int = 0


class AssetDescriptionHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "asset_description"

    @property
    def client_type(self) -> str:
        return "atlas"

    @property
    def required_columns(self) -> set[str]:
        return {"qualified_name", "asset_type", "display_name"}

    @property
    def optional_columns(self) -> set[str]:
        return {"description", "owner"}

    @property
    def default_sheet(self) -> str:
        return "Assets"

    def parse_row(self, row_data: dict, row_number: int) -> AssetDescriptionRecord:
        # Capture any column not in required/optional as a custom attribute
        known = self.required_columns | self.optional_columns
        custom_attrs = {
            k: v for k, v in row_data.items()
            if k not in known and v
        }
        return AssetDescriptionRecord(
            qualified_name=row_data["qualified_name"],
            asset_type=row_data["asset_type"],
            display_name=row_data["display_name"],
            description=row_data.get("description", ""),
            owner=row_data.get("owner", ""),
            custom_attrs=custom_attrs,
            row_number=row_number,
        )

    def execute_batch(self, batch: list[AssetDescriptionRecord], client) -> dict:
        """client is an AtlasClient instance."""
        gt = GuidTracker(starting=-1000)
        entities = []
        for rec in batch:
            attributes = {
                "description": rec.description,
                "userDescription": rec.description,
            }
            if rec.owner:
                attributes["owner"] = rec.owner
            attributes.update(rec.custom_attrs or {})

            entities.append(AtlasEntity(
                name=rec.display_name,
                typeName=rec.asset_type,
                qualified_name=rec.qualified_name,
                guid=gt.get_guid(),
                attributes=attributes,
            ))

        try:
            client.pyapacheatlas.upload_entities(batch=entities)
            return {"succeeded": len(batch), "failed": 0, "errors": []}
        except Exception as e:
            logging.error(f"Asset description batch failed: {e}")
            return {
                "succeeded": 0,
                "failed": len(batch),
                "errors": [str(e)] * len(batch),
            }
