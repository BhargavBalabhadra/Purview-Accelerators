"""
BulkOperationHandler — abstract base for every bulk upload type.

Each handler declares which Purview API surface it talks to:
    client_type = "atlas"  → AtlasClient (Data Map)
    client_type = "uc"     → UnifiedCatalogClient (Unified Catalog)

Adding a new operation:
  1. Pick the right client_type
  2. Subclass BulkOperationHandler
  3. Implement parse_row + execute_batch (+ validate if needed)
  4. Register in handlers/__init__.py
"""
from abc import ABC, abstractmethod
from typing import Any, Literal


ClientType = Literal["atlas", "uc"]


class BulkOperationHandler(ABC):
    """Contract every bulk upload handler must implement."""

    # --- Identity & client selection ---------------------------------------
    @property
    @abstractmethod
    def operation_name(self) -> str:
        """Short ID used in the URL: ?operation=critical_data_element"""

    @property
    @abstractmethod
    def client_type(self) -> ClientType:
        """Which Purview API surface this handler talks to: 'atlas' or 'uc'."""

    # --- Schema -----------------------------------------------------------
    @property
    @abstractmethod
    def required_columns(self) -> set[str]:
        """Columns that must exist in the Excel template."""

    @property
    def optional_columns(self) -> set[str]:
        """Columns the handler will use if present."""
        return set()

    @property
    def default_template(self) -> str:
        return f"{self.operation_name}-template.xlsx"

    @property
    def default_sheet(self) -> str:
        return "Sheet1"

    @property
    def batch_size(self) -> int:
        """How many records per API call. UC ops usually = 1 (no native bulk endpoint)."""
        return 100

    # --- Behavior ----------------------------------------------------------
    @abstractmethod
    def parse_row(self, row_data: dict, row_number: int) -> Any:
        """Convert one row's {column: value} dict into the handler's domain object."""

    def validate(self, record: Any) -> list[str]:
        """Operation-specific validation. Return list of error messages."""
        return []

    @abstractmethod
    def execute_batch(self, batch: list[Any], client) -> dict:
        """
        Send one batch of records to Purview via the provided client.
        `client` is an instance of AtlasClient or UnifiedCatalogClient,
        matching this handler's client_type.

        Returns: {"succeeded": int, "failed": int, "errors": [str, ...]}
        """
