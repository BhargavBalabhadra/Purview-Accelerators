"""
Bulk-create Purview Unified Catalog Governance/Business Domains.
Operation: ?operation=governance_domain
API: POST /datagovernance/catalog/businessdomains

Required RBAC: 'Governance domain creator' role at tenant level.

Excel columns:
    name        (required) — unique domain name
    description (required) — domain description
    type        (required) — FunctionalUnit | LineOfBusiness | DataDomain
                             | Regulatory | Project
    parent_name (optional) — name of parent domain to nest under
    status      (optional) — DRAFT | PUBLISHED (default: DRAFT)
"""
import logging
from dataclasses import dataclass
from typing import Optional

from .base import BulkOperationHandler


VALID_DOMAIN_TYPES = {
    "FunctionalUnit", "LineOfBusiness", "DataDomain", "Regulatory", "Project",
}
VALID_STATUSES = {"DRAFT", "PUBLISHED"}


@dataclass
class GovernanceDomainRecord:
    name: str
    description: str
    type: str
    parent_name: Optional[str] = None
    status: str = "DRAFT"
    row_number: int = 0


class GovernanceDomainHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "governance_domain"

    @property
    def client_type(self) -> str:
        return "uc"

    @property
    def required_columns(self) -> set[str]:
        return {"name", "description", "type"}

    @property
    def optional_columns(self) -> set[str]:
        return {"parent_name", "status"}

    @property
    def default_sheet(self) -> str:
        return "GovernanceDomains"

    @property
    def batch_size(self) -> int:
        # UC API has no bulk endpoint — one POST per domain.
        # batch_size still controls retry/logging granularity.
        return 1

    def parse_row(self, row_data: dict, row_number: int) -> GovernanceDomainRecord:
        return GovernanceDomainRecord(
            name=row_data["name"],
            description=row_data["description"],
            type=row_data["type"],
            parent_name=row_data.get("parent_name") or None,
            status=(row_data.get("status") or "DRAFT").upper(),
            row_number=row_number,
        )

    def validate(self, record: GovernanceDomainRecord) -> list[str]:
        errs = []
        if record.type not in VALID_DOMAIN_TYPES:
            errs.append(
                f"type must be one of {sorted(VALID_DOMAIN_TYPES)}, got '{record.type}'"
            )
        if record.status not in VALID_STATUSES:
            errs.append(
                f"status must be one of {sorted(VALID_STATUSES)}, got '{record.status}'"
            )
        return errs

    def execute_batch(self, batch: list[GovernanceDomainRecord], client) -> dict:
        """client is a UnifiedCatalogClient."""
        succeeded = 0
        failed = 0
        errors = []

        # Lookup parent domains by name — cache so we don't re-fetch per row
        parent_cache: dict[str, str] = {}

        for rec in batch:
            try:
                parent_id = None
                if rec.parent_name:
                    parent_id = parent_cache.get(rec.parent_name) or \
                        self._lookup_domain_id(client, rec.parent_name)
                    if not parent_id:
                        raise ValueError(
                            f"Parent domain '{rec.parent_name}' not found"
                        )
                    parent_cache[rec.parent_name] = parent_id

                payload = {
                    "name": rec.name,
                    "description": rec.description,
                    "type": rec.type,
                    "status": rec.status,
                }
                if parent_id:
                    payload["parentId"] = parent_id

                response = client.post("businessdomains", json=payload)
                new_id = response.get("id")
                # Cache this domain too — useful if other rows reference it as parent
                parent_cache[rec.name] = new_id
                logging.info(f"Created governance domain '{rec.name}' (id={new_id})")
                succeeded += 1
            except Exception as e:
                logging.error(f"Failed to create domain '{rec.name}': {e}")
                failed += 1
                errors.append(f"row {rec.row_number} ({rec.name}): {e}")

        return {"succeeded": succeeded, "failed": failed, "errors": errors}

    @staticmethod
    def _lookup_domain_id(client, name: str) -> Optional[str]:
        """Search for a domain by name and return its id."""
        result = client.get("businessdomains", params={"keyword": name, "top": 50})
        for domain in result.get("value", []):
            if domain.get("name") == name:
                return domain.get("id")
        return None
