"""
Bulk-attach labels (free-form tags) to existing Purview entities.
Operation: ?operation=label

Labels are simpler than classifications — just string tags, no schema.
Uses the Atlas labels endpoint: PUT /api/atlas/v2/entity/uniqueAttribute/type/{type}

Excel columns:
    qualified_name (required)
    asset_type     (required)
    labels         (required) — comma-separated, e.g. "PII,Verified,Q4-2025"
    mode           (optional) — "append" (default) or "replace"
"""
import logging
from dataclasses import dataclass, field

from .base import BulkOperationHandler


@dataclass
class LabelRecord:
    qualified_name: str
    asset_type: str
    labels: list[str] = field(default_factory=list)
    mode: str = "append"  # append or replace
    row_number: int = 0


class LabelHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "label"

    @property
    def client_type(self) -> str:
        return "atlas"

    @property
    def required_columns(self) -> set[str]:
        return {"qualified_name", "asset_type", "labels"}

    @property
    def optional_columns(self) -> set[str]:
        return {"mode"}

    @property
    def default_sheet(self) -> str:
        return "Labels"

    def parse_row(self, row_data: dict, row_number: int) -> LabelRecord:
        raw = row_data.get("labels", "")
        label_list = [lbl.strip() for lbl in str(raw).split(",") if lbl.strip()]
        mode = (row_data.get("mode") or "append").lower()
        if mode not in ("append", "replace"):
            mode = "append"
        return LabelRecord(
            qualified_name=row_data["qualified_name"],
            asset_type=row_data["asset_type"],
            labels=label_list,
            mode=mode,
            row_number=row_number,
        )

    def validate(self, record: LabelRecord) -> list[str]:
        if not record.labels:
            return ["At least one label is required"]
        return []

    def execute_batch(self, batch: list[LabelRecord], client) -> dict:
        """client is an AtlasClient. Uses the labels REST endpoint directly."""
        succeeded = 0
        failed = 0
        errors = []

        for rec in batch:
            try:
                method = "PUT" if rec.mode == "replace" else "POST"
                path = (
                    f"/api/atlas/v2/entity/uniqueAttribute/type/{rec.asset_type}"
                    f"/labels"
                )
                client.request(
                    method=method,
                    path=path,
                    json=rec.labels,
                    params={"attr:qualifiedName": rec.qualified_name},
                )
                succeeded += 1
            except Exception as e:
                logging.error(f"Label attach failed for {rec.qualified_name}: {e}")
                failed += 1
                errors.append(f"row {rec.row_number}: {e}")
        return {"succeeded": succeeded, "failed": failed, "errors": errors}
