"""
Bulk-create Unified Catalog Data Products.
Operation: ?operation=uc_data_product
API: POST /datagovernance/catalog/dataProducts

UC Data Products are NOT the same as Atlas DataProduct entities. UC ones live
in the governance plane; Atlas ones live in the technical plane. Use
asset_description with asset_type='DataProduct' for the Atlas equivalent.

Required RBAC: 'Data Product Owner' role on the governance domain.

Excel columns:
    name             (required)
    domain_name      (required) — governance domain owning the product
    description      (required)
    type             (optional) — Master | Operational | Reference (default: Master)
    update_frequency (optional) — Daily | Weekly | Monthly | Hourly (default: Daily)
    business_use     (optional)
    status           (optional) — DRAFT | PUBLISHED (default: DRAFT)
"""
import logging
from dataclasses import dataclass
from typing import Optional

from .base import BulkOperationHandler


VALID_TYPES = {"Master", "Operational", "Reference"}
VALID_FREQUENCIES = {"Hourly", "Daily", "Weekly", "Monthly", "Quarterly", "Yearly"}
VALID_STATUSES = {"DRAFT", "PUBLISHED"}


@dataclass
class UCDataProductRecord:
    name: str
    domain_name: str
    description: str
    type: str = "Master"
    update_frequency: str = "Daily"
    business_use: str = ""
    status: str = "DRAFT"
    row_number: int = 0


class UCDataProductHandler(BulkOperationHandler):

    @property
    def operation_name(self) -> str:
        return "uc_data_product"

    @property
    def client_type(self) -> str:
        return "uc"

    @property
    def required_columns(self) -> set[str]:
        return {"name", "domain_name", "description"}

    @property
    def optional_columns(self) -> set[str]:
        return {"type", "update_frequency", "business_use", "status"}

    @property
    def default_sheet(self) -> str:
        return "DataProducts"

    @property
    def batch_size(self) -> int:
        return 1

    def parse_row(self, row_data: dict, row_number: int) -> UCDataProductRecord:
        return UCDataProductRecord(
            name=row_data["name"],
            domain_name=row_data["domain_name"],
            description=row_data["description"],
            type=row_data.get("type") or "Master",
            update_frequency=row_data.get("update_frequency") or "Daily",
            business_use=row_data.get("business_use") or "",
            status=(row_data.get("status") or "DRAFT").upper(),
            row_number=row_number,
        )

    def validate(self, record: UCDataProductRecord) -> list[str]:
        errs = []
        if record.type not in VALID_TYPES:
            errs.append(f"type must be one of {sorted(VALID_TYPES)}")
        if record.update_frequency not in VALID_FREQUENCIES:
            errs.append(f"update_frequency must be one of {sorted(VALID_FREQUENCIES)}")
        if record.status not in VALID_STATUSES:
            errs.append(f"status must be one of {sorted(VALID_STATUSES)}")
        return errs

    def execute_batch(self, batch: list[UCDataProductRecord], client) -> dict:
        succeeded = 0
        failed = 0
        errors = []
        domain_cache: dict[str, str] = {}

        for rec in batch:
            try:
                domain_id = domain_cache.get(rec.domain_name)
                if not domain_id:
                    domain_id = self._lookup_domain_id(client, rec.domain_name)
                    if not domain_id:
                        raise ValueError(
                            f"Domain '{rec.domain_name}' not found"
                        )
                    domain_cache[rec.domain_name] = domain_id

                payload = {
                    "name": rec.name,
                    "description": rec.description,
                    "domain": domain_id,
                    "type": rec.type,
                    "updateFrequency": rec.update_frequency,
                    "status": rec.status,
                }
                if rec.business_use:
                    payload["businessUse"] = rec.business_use

                client.post("dataProducts", json=payload)
                logging.info(f"Created UC data product '{rec.name}'")
                succeeded += 1
            except Exception as e:
                logging.error(f"Failed UC data product '{rec.name}': {e}")
                failed += 1
                errors.append(f"row {rec.row_number} ({rec.name}): {e}")

        return {"succeeded": succeeded, "failed": failed, "errors": errors}

    @staticmethod
    def _lookup_domain_id(client, name: str) -> Optional[str]:
        result = client.get("businessdomains", params={"keyword": name, "top": 50})
        for d in result.get("value", []):
            if d.get("name") == name:
                return d.get("id")
        return None
