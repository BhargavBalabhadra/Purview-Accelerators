"""Tests for the multi-operation bulk upload architecture."""
import io

import pytest
from openpyxl import Workbook

from handlers import get_handler, list_operations
from services.excel_reader import ExcelReaderService


def build_xlsx(headers: list, rows: list, sheet_name: str) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name
    ws.append(headers)
    for r in rows:
        ws.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


class TestRegistry:
    def test_lists_all_operations(self):
        ops = list_operations()
        names = {op["operation"] for op in ops}
        assert names == {
            "asset_description", "classification", "label",
            "governance_domain", "critical_data_element",
            "cde_mapping", "uc_data_product",
        }

    def test_each_op_declares_api_surface(self):
        for op in list_operations():
            assert op["api_surface"] in ("atlas", "uc")

    def test_atlas_and_uc_partition(self):
        ops = list_operations()
        by_surface = {}
        for op in ops:
            by_surface.setdefault(op["api_surface"], []).append(op["operation"])
        assert "asset_description" in by_surface["atlas"]
        assert "governance_domain" in by_surface["uc"]
        assert "critical_data_element" in by_surface["uc"]

    def test_unknown_operation_raises(self):
        with pytest.raises(ValueError, match="Unknown operation"):
            get_handler("nonexistent")


class TestAssetDescriptionHandler:
    def test_parses_with_custom_columns(self):
        data = build_xlsx(
            ["qualified_name", "asset_type", "display_name", "description", "domain"],
            [["q1", "azure_sql_table", "Customer", "Master", "Sales"]],
            "Assets",
        )
        handler = get_handler("asset_description")
        records, errors = ExcelReaderService().parse(data, handler)
        assert len(records) == 1
        assert errors == []
        assert records[0].custom_attrs == {"domain": "Sales"}


class TestClassificationHandler:
    def test_parses_classifications_list(self):
        data = build_xlsx(
            ["qualified_name", "asset_type", "classifications"],
            [["q1", "azure_sql_table", "A,B,C"]],
            "Classifications",
        )
        handler = get_handler("classification")
        records, errors = ExcelReaderService().parse(data, handler)
        assert len(records) == 1
        assert records[0].classifications == ["A", "B", "C"]

    def test_empty_classifications_fails_validation(self):
        data = build_xlsx(
            ["qualified_name", "asset_type", "classifications"],
            [["q1", "azure_sql_table", "   "]],
            "Classifications",
        )
        handler = get_handler("classification")
        records, errors = ExcelReaderService().parse(data, handler)
        # Whitespace passes required-cell check but fails handler.validate()
        assert len(records) == 0
        assert any("classifications is required" in e["message"]
                   or "At least one classification" in e["message"]
                   for e in errors)


class TestLabelHandler:
    def test_parses_with_mode(self):
        data = build_xlsx(
            ["qualified_name", "asset_type", "labels", "mode"],
            [
                ["q1", "azure_sql_table", "X,Y", "append"],
                ["q2", "azure_blob_path", "Z", "replace"],
                ["q3", "azure_blob_path", "Z", "INVALID"],  # falls back to append
            ],
            "Labels",
        )
        handler = get_handler("label")
        records, _ = ExcelReaderService().parse(data, handler)
        assert records[0].mode == "append"
        assert records[1].mode == "replace"
        assert records[2].mode == "append"


class TestGovernanceDomainHandler:
    def test_parses_valid_row(self):
        data = build_xlsx(
            ["name", "description", "type", "parent_name", "status"],
            [["Sales", "Sales BU", "FunctionalUnit", "", "PUBLISHED"]],
            "GovernanceDomains",
        )
        h = get_handler("governance_domain")
        records, errors = ExcelReaderService().parse(data, h)
        assert len(records) == 1
        assert records[0].type == "FunctionalUnit"
        assert records[0].status == "PUBLISHED"
        assert records[0].parent_name is None

    def test_invalid_type_fails_validation(self):
        data = build_xlsx(
            ["name", "description", "type"],
            [["X", "y", "NotARealType"]],
            "GovernanceDomains",
        )
        h = get_handler("governance_domain")
        records, errors = ExcelReaderService().parse(data, h)
        assert len(records) == 0
        assert any("type must be one of" in e["message"] for e in errors)


class TestCDEHandler:
    def test_data_type_uppercased(self):
        data = build_xlsx(
            ["name", "domain_name", "description", "data_type"],
            [["Customer ID", "Sales", "Customer identifier", "text"]],
            "CriticalDataElements",
        )
        h = get_handler("critical_data_element")
        records, _ = ExcelReaderService().parse(data, h)
        assert records[0].data_type == "TEXT"

    def test_name_length_validation(self):
        data = build_xlsx(
            ["name", "domain_name", "description", "data_type"],
            [["x" * 300, "Sales", "y", "TEXT"]],
            "CriticalDataElements",
        )
        h = get_handler("critical_data_element")
        records, errors = ExcelReaderService().parse(data, h)
        assert len(records) == 0
        assert any("max length" in e["message"] for e in errors)


class TestCDEMappingHandler:
    def test_defaults_entity_type(self):
        data = build_xlsx(
            ["cde_name", "domain_name", "entity_id"],
            [["Customer ID", "Sales", "abc-123"]],
            "CDEMappings",
        )
        h = get_handler("cde_mapping")
        records, _ = ExcelReaderService().parse(data, h)
        assert records[0].entity_type == "CRITICALDATACOLUMN"
        assert records[0].relationship == "Related"
