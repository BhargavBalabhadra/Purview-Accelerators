"""
Purview client abstraction.

Two clients implement this surface:
  - AtlasClient         → /api/atlas/v2/...      (Data Map entities, classifications, labels)
  - UnifiedCatalogClient→ /datagovernance/...    (Domains, CDEs, Data Products, OKRs)

Handlers pick which one they need via the `client_type` property.
The executor wires them up at runtime.
"""
from abc import ABC, abstractmethod
from typing import Any


class PurviewClientBase(ABC):
    """Common interface for both Purview API surfaces."""

    @abstractmethod
    def request(
        self,
        method: str,
        path: str,
        json: Any = None,
        params: dict = None,
    ) -> dict:
        """
        Make an authenticated HTTP request and return the JSON response.

        Args:
            method: HTTP verb (GET, POST, PUT, PATCH, DELETE)
            path:   Path relative to the API base (no leading slash needed)
            json:   Body to serialize as JSON
            params: Query string parameters
        """
