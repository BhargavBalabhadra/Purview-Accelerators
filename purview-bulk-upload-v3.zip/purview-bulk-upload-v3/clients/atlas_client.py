"""
Atlas Data Map client — wraps PyApacheAtlas for entities, classifications, labels.

Endpoint: https://{account}.purview.azure.com/api/atlas/v2/
Audience: https://purview.azure.net

Use this client for any operation that works with technical metadata:
  - AtlasEntity payloads (descriptions, owners, custom attributes)
  - Classifications (Atlas type system)
  - Labels (free-form tags)
  - Atlas-style glossary terms (legacy, not UC)
"""
import logging
import os
from typing import Any, Optional

from azure.identity import DefaultAzureCredential
from pyapacheatlas.auth import AzCredentialWrapper
from pyapacheatlas.core import PurviewClient

from .base import PurviewClientBase


class AtlasClient(PurviewClientBase):
    """Atlas Data Map REST client (PyApacheAtlas under the hood)."""

    def __init__(self, account_name: Optional[str] = None):
        self.account_name = account_name or os.environ["PURVIEW_ACCOUNT_NAME"]
        self._client: Optional[PurviewClient] = None

    @property
    def pyapacheatlas(self) -> PurviewClient:
        """Direct access to the PyApacheAtlas client for native SDK calls."""
        if self._client is None:
            credential = DefaultAzureCredential(
                exclude_interactive_browser_credential=True,
                exclude_visual_studio_code_credential=True,
            )
            auth = AzCredentialWrapper(credential=credential)
            self._client = PurviewClient(
                account_name=self.account_name, authentication=auth
            )
            logging.info(f"AtlasClient ready for {self.account_name}")
        return self._client

    def request(self, method: str, path: str, json: Any = None,
                params: dict = None) -> dict:
        """
        Generic Atlas REST passthrough.
        Useful for endpoints PyApacheAtlas doesn't natively wrap (e.g. labels).
        """
        endpoint = path if path.startswith("/") else f"/{path}"
        return self.pyapacheatlas._make_request(  # noqa: SLF001
            method=method,
            api_endpoint=endpoint,
            json=json,
            params=params or {},
        )
