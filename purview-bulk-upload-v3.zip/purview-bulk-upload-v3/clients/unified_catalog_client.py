"""
Unified Catalog REST client — direct HTTP since no Python SDK exists yet.

Endpoint: https://{account}.purview.azure.com/datagovernance/catalog/
Audience: https://purview.azure.net
API version: 2025-09-15-preview (public preview from Oct 2025)

Use this client for any Unified Catalog operation:
  - Governance / business domains
  - Critical Data Elements (CDEs)
  - Data Products (UC native — different from Atlas DataProduct type)
  - OKRs
  - UC-native glossary terms
  - Data access policies

The MI/SP needs UC-specific RBAC roles assigned at the governance domain
level (Data Steward, Data Product Owner, Governance domain creator/owner)
— NOT just the Atlas Data Curator role.
"""
import logging
import os
import time
from typing import Any, Optional

import requests
from azure.identity import DefaultAzureCredential

from .base import PurviewClientBase


# Public preview API version. Update when GA version ships.
DEFAULT_API_VERSION = "2025-09-15-preview"

# Scope for AAD token. Same as Atlas — same Purview resource, different paths.
PURVIEW_SCOPE = "https://purview.azure.net/.default"

# Token refresh buffer — refresh 5 minutes before expiry
TOKEN_REFRESH_BUFFER_SEC = 300


class UnifiedCatalogClient(PurviewClientBase):
    """Direct REST client for the Purview Unified Catalog data plane."""

    def __init__(
        self,
        account_name: Optional[str] = None,
        api_version: str = DEFAULT_API_VERSION,
    ):
        self.account_name = account_name or os.environ["PURVIEW_ACCOUNT_NAME"]
        self.api_version = api_version
        self.base_url = (
            f"https://{self.account_name}.purview.azure.com"
            f"/datagovernance/catalog"
        )
        self._credential: Optional[DefaultAzureCredential] = None
        self._token: Optional[str] = None
        self._token_expires_at: float = 0
        self._session = requests.Session()

    # ---- Auth -------------------------------------------------------------
    @property
    def credential(self) -> DefaultAzureCredential:
        if self._credential is None:
            self._credential = DefaultAzureCredential(
                exclude_interactive_browser_credential=True,
                exclude_visual_studio_code_credential=True,
            )
            logging.info("UnifiedCatalogClient credential initialized")
        return self._credential

    def _get_token(self) -> str:
        """Get a cached AAD token, refreshing if expired or close to expiring."""
        now = time.time()
        if self._token and now < self._token_expires_at - TOKEN_REFRESH_BUFFER_SEC:
            return self._token
        token = self.credential.get_token(PURVIEW_SCOPE)
        self._token = token.token
        self._token_expires_at = token.expires_on
        logging.info(f"UC token refreshed, expires in {token.expires_on - now:.0f}s")
        return self._token

    # ---- HTTP -------------------------------------------------------------
    def request(
        self,
        method: str,
        path: str,
        json: Any = None,
        params: dict = None,
    ) -> dict:
        """
        Make a UC REST request. Path is relative to /datagovernance/catalog/.
        api-version is added automatically.
        """
        clean_path = path.lstrip("/")
        url = f"{self.base_url}/{clean_path}"

        query = {"api-version": self.api_version}
        if params:
            query.update(params)

        headers = {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        logging.debug(f"UC {method} {url} params={query}")
        resp = self._session.request(
            method=method,
            url=url,
            headers=headers,
            params=query,
            json=json,
            timeout=60,
        )

        # Raise for HTTP errors with informative messages
        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            raise UnifiedCatalogAPIError(
                status_code=resp.status_code,
                message=f"UC API {method} {clean_path} failed",
                response_body=body,
            )

        # Some endpoints return 204 No Content
        if resp.status_code == 204 or not resp.content:
            return {}
        return resp.json()

    # ---- Convenience wrappers ---------------------------------------------
    def get(self, path: str, params: dict = None) -> dict:
        return self.request("GET", path, params=params)

    def post(self, path: str, json: Any = None, params: dict = None) -> dict:
        return self.request("POST", path, json=json, params=params)

    def put(self, path: str, json: Any = None, params: dict = None) -> dict:
        return self.request("PUT", path, json=json, params=params)

    def delete(self, path: str, params: dict = None) -> dict:
        return self.request("DELETE", path, params=params)


class UnifiedCatalogAPIError(Exception):
    """Raised on non-2xx responses from the UC API. Carries structured detail."""

    def __init__(self, status_code: int, message: str, response_body: Any):
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(f"{message} [HTTP {status_code}]: {response_body}")
