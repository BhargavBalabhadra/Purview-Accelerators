"""
Blob Storage client — downloads Excel template from Azure Storage Account.
Uses Managed Identity in production (DefaultAzureCredential auto-resolves).
"""
import logging
import os
from typing import Optional

from azure.core.exceptions import ResourceNotFoundError
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient


class BlobClientService:
    """Wraps blob download with Managed Identity authentication."""

    def __init__(self, storage_account: Optional[str] = None,
                 container: Optional[str] = None):
        self.storage_account = storage_account or os.environ["STORAGE_ACCOUNT_NAME"]
        self.container = container or os.environ["BLOB_CONTAINER_NAME"]
        self._client: Optional[BlobServiceClient] = None

    @property
    def client(self) -> BlobServiceClient:
        """Lazy-init the BlobServiceClient with DefaultAzureCredential."""
        if self._client is None:
            credential = DefaultAzureCredential(
                # Speed up cold starts by skipping unused credential types
                exclude_interactive_browser_credential=True,
                exclude_visual_studio_code_credential=True,
            )
            account_url = f"https://{self.storage_account}.blob.core.windows.net"
            self._client = BlobServiceClient(
                account_url=account_url, credential=credential
            )
            logging.info(f"BlobServiceClient initialized for {account_url}")
        return self._client

    def download_blob(self, blob_name: str) -> bytes:
        """
        Download the named blob and return its raw bytes.

        Raises:
            FileNotFoundError: blob does not exist in the container
        """
        try:
            blob_client = self.client.get_blob_client(
                container=self.container, blob=blob_name
            )
            logging.info(
                f"Downloading blob: {self.container}/{blob_name}"
            )
            stream = blob_client.download_blob()
            return stream.readall()
        except ResourceNotFoundError:
            raise FileNotFoundError(
                f"Blob '{blob_name}' not found in container '{self.container}'"
            )

    def list_templates(self, prefix: str = "") -> list[str]:
        """List available template files (useful for diagnostics endpoint)."""
        container_client = self.client.get_container_client(self.container)
        return [b.name for b in container_client.list_blobs(name_starts_with=prefix)]
