"""
PurviewExecutor — drives a handler over its records.

Resolves the correct client (Atlas vs Unified Catalog) based on the handler's
declared client_type. Handles batching and retry; the API call itself is
delegated to handler.execute_batch().
"""
import logging
import time
from typing import Optional

from clients import AtlasClient, UnifiedCatalogClient
from clients.base import PurviewClientBase
from handlers.base import BulkOperationHandler


MAX_RETRIES = 3
RETRY_BACKOFF_SEC = 2


class PurviewExecutor:
    """Coordinates client resolution + batching + retry."""

    def __init__(self):
        # Both clients are lazy-init — only the one actually used pays the
        # auth cost. Re-used across batches in a single function invocation.
        self._atlas: Optional[AtlasClient] = None
        self._uc: Optional[UnifiedCatalogClient] = None

    def _get_client(self, handler: BulkOperationHandler) -> PurviewClientBase:
        """Return the client matching the handler's declared client_type."""
        if handler.client_type == "atlas":
            if self._atlas is None:
                self._atlas = AtlasClient()
            return self._atlas
        if handler.client_type == "uc":
            if self._uc is None:
                self._uc = UnifiedCatalogClient()
            return self._uc
        raise ValueError(
            f"Unknown client_type '{handler.client_type}' on handler "
            f"{handler.operation_name}"
        )

    def run(self, handler: BulkOperationHandler, records: list) -> dict:
        """Execute a handler's records in batches with retry."""
        if not records:
            return {"succeeded": 0, "failed": 0, "errors": []}

        client = self._get_client(handler)
        logging.info(
            f"Operation '{handler.operation_name}' "
            f"using {handler.client_type.upper()} client"
        )

        batch_size = handler.batch_size
        total = (len(records) + batch_size - 1) // batch_size

        agg = {"succeeded": 0, "failed": 0, "errors": []}

        for i in range(0, len(records), batch_size):
            batch = records[i : i + batch_size]
            batch_num = (i // batch_size) + 1
            logging.info(
                f"[{handler.operation_name}] batch {batch_num}/{total} "
                f"({len(batch)} records)"
            )

            result = self._execute_with_retry(handler, batch, client)
            agg["succeeded"] += result["succeeded"]
            agg["failed"] += result["failed"]
            agg["errors"].extend(result["errors"])

        return agg

    def _execute_with_retry(
        self,
        handler: BulkOperationHandler,
        batch: list,
        client: PurviewClientBase,
    ) -> dict:
        last_error: Optional[Exception] = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                return handler.execute_batch(batch, client)
            except Exception as e:
                last_error = e
                msg = str(e).lower()
                is_transient = any(
                    s in msg for s in [
                        "429", "500", "502", "503", "504", "timeout", "connection",
                    ]
                )
                if not is_transient or attempt == MAX_RETRIES:
                    raise
                wait = RETRY_BACKOFF_SEC * (2 ** (attempt - 1))
                logging.warning(
                    f"Transient error attempt {attempt}, retry in {wait}s: {e}"
                )
                time.sleep(wait)
        raise last_error  # type: ignore[misc]
