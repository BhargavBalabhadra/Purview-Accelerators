"""
Generic Excel reader — handler-agnostic.
Validates required columns based on the handler, then yields {col: value} dicts.
The handler's parse_row converts each dict into its own domain object.
"""
import io
import logging
from typing import Any

from openpyxl import load_workbook

from handlers.base import BulkOperationHandler


class ExcelReaderService:

    def parse(
        self,
        excel_bytes: bytes,
        handler: BulkOperationHandler,
        sheet_name: str = None,
    ) -> tuple[list[Any], list[dict]]:
        """
        Parse Excel bytes against a handler's schema.

        Returns:
            records: list of domain objects produced by handler.parse_row()
            errors: list of {row, field, message} dicts for skipped rows
        """
        sheet_name = sheet_name or handler.default_sheet

        wb = load_workbook(io.BytesIO(excel_bytes), read_only=True, data_only=True)

        if sheet_name not in wb.sheetnames:
            raise ValueError(
                f"Sheet '{sheet_name}' not found. Available: {wb.sheetnames}"
            )

        ws = wb[sheet_name]
        rows_iter = ws.iter_rows(values_only=True)

        try:
            header_raw = next(rows_iter)
        except StopIteration:
            raise ValueError("Excel sheet is empty")

        headers = [self._normalize_header(h) for h in header_raw]
        logging.info(f"Columns for '{handler.operation_name}': {headers}")

        missing = handler.required_columns - set(headers)
        if missing:
            raise ValueError(
                f"Required columns missing for {handler.operation_name}: "
                f"{sorted(missing)}"
            )

        records: list[Any] = []
        errors: list[dict] = []
        seen_keys: set[str] = set()

        for row_num, row in enumerate(rows_iter, start=2):
            if all(cell is None or str(cell).strip() == "" for cell in row):
                continue

            row_data: dict[str, str] = {}
            for idx, col_name in enumerate(headers):
                if not col_name or idx >= len(row):
                    continue
                val = row[idx]
                row_data[col_name] = str(val).strip() if val is not None else ""

            # Required-column non-empty check
            row_errors = []
            for col in handler.required_columns:
                if not row_data.get(col):
                    row_errors.append({
                        "row": row_num,
                        "field": col,
                        "message": f"{col} is required",
                    })
            if row_errors:
                errors.extend(row_errors)
                continue

            # Handler-specific parse
            try:
                record = handler.parse_row(row_data, row_num)
            except Exception as e:
                errors.append({
                    "row": row_num, "field": "row",
                    "message": f"parse error: {e}",
                })
                continue

            # Handler-specific validation
            extra_errors = [
                {"row": row_num, "field": "validation", "message": m}
                for m in handler.validate(record)
            ]
            if extra_errors:
                errors.extend(extra_errors)
                continue

            # Dedupe on the handler's natural key (first required col that's a name/id)
            dedupe_col = self._dedupe_key(handler)
            if dedupe_col:
                key = row_data.get(dedupe_col)
                if key:
                    if key in seen_keys:
                        errors.append({
                            "row": row_num, "field": dedupe_col,
                            "message": f"Duplicate {dedupe_col}: {key}",
                        })
                        continue
                    seen_keys.add(key)

            records.append(record)

        wb.close()
        return records, errors

    @staticmethod
    def _dedupe_key(handler) -> str:
        """Pick the column used to detect duplicates within a single template."""
        # Atlas handlers identify entities by qualified_name; UC handlers by name.
        # Fall back to None (no dedupe) if neither is present.
        for candidate in ("qualified_name", "name", "cde_name"):
            if candidate in handler.required_columns:
                return candidate
        return ""

    @staticmethod
    def _normalize_header(value) -> str:
        if value is None:
            return ""
        return str(value).strip().lower().replace(" ", "_")
