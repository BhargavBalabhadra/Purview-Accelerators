"""
Azure Function App — Purview Bulk Upload (multi-operation)
==========================================================

ONE endpoint, MANY operations:
    POST /api/bulk-upload?operation=asset_description
    POST /api/bulk-upload?operation=classification
    POST /api/bulk-upload?operation=label
    POST /api/bulk-upload?operation=<future_op>

Each operation is implemented by a handler in handlers/.
Adding a new operation requires NO changes to this file.
"""
import json
import logging

import azure.functions as func

from handlers import get_handler, list_operations
from services.blob_client import BlobClientService
from services.excel_reader import ExcelReaderService
from services.purview_client import PurviewExecutor

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


@app.route(route="bulk-upload", methods=["POST"])
def bulk_upload(req: func.HttpRequest) -> func.HttpResponse:
    """
    Generic bulk-upload endpoint.

    Query params:
        operation (required) : asset_description | classification | label | ...
        template  (optional) : blob name; defaults per handler
        sheet     (optional) : sheet name; defaults per handler
        dry_run   (optional) : true|false; default false
    """
    logging.info("=" * 60)

    operation = req.params.get("operation")
    if not operation:
        return _err(400, "Missing required query param: operation",
                    available=[op["operation"] for op in list_operations()])

    # --- 1. Resolve handler ---
    try:
        handler = get_handler(operation)
        logging.info(f"Operation: {operation}")
    except ValueError as e:
        return _err(400, str(e))

    # --- 2. Resolve params (with handler-specific defaults) ---
    template_blob = req.params.get("template", handler.default_template)
    sheet_name = req.params.get("sheet", handler.default_sheet)
    dry_run = req.params.get("dry_run", "false").lower() == "true"
    logging.info(f"template={template_blob} sheet={sheet_name} dry_run={dry_run}")

    # --- 3. Download template ---
    try:
        excel_bytes = BlobClientService().download_blob(template_blob)
        logging.info(f"Downloaded {len(excel_bytes):,} bytes")
    except FileNotFoundError as e:
        return _err(404, str(e))
    except Exception as e:
        return _err(500, f"Blob error: {e}")

    # --- 4. Parse Excel ---
    try:
        records, validation_errors = ExcelReaderService().parse(
            excel_bytes, handler, sheet_name=sheet_name
        )
        logging.info(
            f"Parsed {len(records)} records, {len(validation_errors)} errors"
        )
    except ValueError as e:
        return _err(400, f"Excel error: {e}")
    except Exception as e:
        return _err(500, f"Parse error: {e}")

    if not records:
        return _err(400, "No valid records found",
                    validation_errors=validation_errors)

    # --- 5. Dry-run short-circuit ---
    if dry_run:
        return _ok(200, {
            "status": "dry_run",
            "operation": operation,
            "parsed_records": len(records),
            "validation_errors": validation_errors,
        })

    # --- 6. Execute ---
    try:
        result = PurviewExecutor().run(handler, records)
        logging.info(f"Done: {result}")
    except Exception as e:
        logging.exception("Execution failed")
        return _err(500, f"Purview error: {e}")

    body = {
        "status": "success" if result["failed"] == 0 else "partial_success",
        "operation": operation,
        "total_parsed": len(records),
        "uploaded": result["succeeded"],
        "failed": result["failed"],
        "validation_errors": validation_errors,
        "upload_errors": result["errors"],
    }
    return _ok(200 if result["failed"] == 0 else 207, body)


@app.route(route="operations", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def list_ops(req: func.HttpRequest) -> func.HttpResponse:
    """Discovery endpoint — lists all registered bulk operations and their schemas."""
    return _ok(200, {"operations": list_operations()})


@app.route(route="health", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def health(req: func.HttpRequest) -> func.HttpResponse:
    return _ok(200, {"status": "healthy"})


# ---- helpers ---------------------------------------------------------------
def _ok(status: int, body: dict) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps(body, indent=2),
        status_code=status,
        mimetype="application/json",
    )


def _err(status: int, message: str, **extra) -> func.HttpResponse:
    payload = {"status": "error", "message": message, **extra}
    return func.HttpResponse(
        json.dumps(payload, indent=2),
        status_code=status,
        mimetype="application/json",
    )
