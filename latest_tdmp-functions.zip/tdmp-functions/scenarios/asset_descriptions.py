"""Scenario 3: Bulk upload data asset descriptions."""
from pyapacheatlas.core import AtlasEntity

from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


@register
class AssetDescriptionsScenario(ScenarioBase):
    name             = "asset_descriptions"
    default_template = "asset_descriptions.xlsx"
    schema = Schema(
        name="asset_descriptions",
        fields=[
            FieldSpec("qualified_name",   required=True,  type="str"),
            FieldSpec("asset_type",       required=True,  type="str"),
            FieldSpec("display_name",     required=True,  type="str", max_length=200),
            FieldSpec("description",      required=True,  type="str", max_length=4000),
            FieldSpec("user_description", required=False, type="str", max_length=4000),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        entities = [
            AtlasEntity(
                name=row["display_name"],
                typeName=row["asset_type"],
                qualified_name=row["qualified_name"],
                attributes={
                    "description":     row["description"],
                    "userDescription": row.get("user_description") or row["description"],
                },
            )
            for row in rows
        ]
        log.info(f"asset_descriptions prepared count={len(entities)}")
        return ctx.entity_repo.upsert_bulk(entities)
