"""Scenario 6: Bulk creation of Governance Domains."""
from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


@register
class GovernanceDomainsScenario(ScenarioBase):
    name             = "governance_domains"
    default_template = "governance_domains.xlsx"
    schema = Schema(
        name="governance_domains",
        fields=[
            FieldSpec("name",                  required=True,  type="str", max_length=100),
            FieldSpec("qualified_name",        required=True,  type="str"),
            FieldSpec("description",           required=True,  type="str", max_length=4000),
            FieldSpec("owner_email",           required=True,  type="email"),
            FieldSpec("parent_qualified_name", required=False, type="str"),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        results = {"success": 0, "errors": []}
        for row in rows:
            try:
                ctx.domain_repo.create(
                    name=row["name"],
                    qualified_name=row["qualified_name"],
                    description=row["description"],
                    owner_email=row["owner_email"],
                    parent_qualified_name=row.get("parent_qualified_name", ""),
                )
                results["success"] += 1
            except Exception as e:
                results["errors"].append({
                    "domain": row["name"],
                    "error": str(e),
                })
        return results
