"""Scenario 1: Bulk apply Atlas classifications to data assets."""
from collections import defaultdict

from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


@register
class AssetClassificationsScenario(ScenarioBase):
    name             = "asset_classifications"
    default_template = "asset_classifications.xlsx"
    schema = Schema(
        name="asset_classifications",
        fields=[
            FieldSpec("qualified_name",      required=True,  type="str"),
            FieldSpec("asset_type",          required=True,  type="str"),
            FieldSpec("classification_name", required=True,  type="str"),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        # Group by (qualified_name, asset_type) so multiple classifications
        # for the same asset hit the API in one call.
        grouped: dict[tuple[str, str], list[str]] = defaultdict(list)
        row_meta: dict[tuple[str, str], int] = {}
        for row in rows:
            key = (row["qualified_name"], row["asset_type"])
            grouped[key].append(row["classification_name"])
            row_meta[key] = row.get("_excel_row", 0)

        results = {"success": 0, "errors": []}
        for (qn, atype), names in grouped.items():
            try:
                ctx.classification_repo.apply(atype, qn, names)
                results["success"] += 1
            except Exception as e:
                results["errors"].append({
                    "row": row_meta[key],
                    "qualified_name": qn,
                    "error": str(e),
                })
        return results
