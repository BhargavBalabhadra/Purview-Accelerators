"""Scenario 2: Bulk add free-form labels (tags) to data assets."""
from collections import defaultdict

from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


@register
class AssetLabelsScenario(ScenarioBase):
    name             = "asset_labels"
    default_template = "asset_labels.xlsx"
    schema = Schema(
        name="asset_labels",
        fields=[
            FieldSpec("qualified_name", required=True, type="str"),
            FieldSpec("asset_type",     required=True, type="str"),
            FieldSpec("label",          required=True, type="str", max_length=50),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        grouped: dict[tuple[str, str], list[str]] = defaultdict(list)
        for row in rows:
            grouped[(row["qualified_name"], row["asset_type"])].append(row["label"])

        results = {"success": 0, "errors": []}
        for (qn, atype), labels in grouped.items():
            try:
                guid = ctx.entity_repo.get_guid(qn, atype)
                ctx.label_repo.add_labels(guid, labels)
                results["success"] += 1
            except Exception as e:
                results["errors"].append({
                    "qualified_name": qn,
                    "error": str(e),
                })
        return results
