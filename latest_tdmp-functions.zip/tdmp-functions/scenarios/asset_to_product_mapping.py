"""Scenario 7: Map data assets to data products in bulk."""
from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


ASSET_PRODUCT_RELATIONSHIP = "DataProductDataAsset"


@register
class AssetToProductMappingScenario(ScenarioBase):
    name             = "asset_to_product_mapping"
    default_template = "asset_to_product_mapping.xlsx"
    schema = Schema(
        name="asset_to_product_mapping",
        fields=[
            FieldSpec("asset_qualified_name",        required=True, type="str"),
            FieldSpec("asset_type",                  required=True, type="str"),
            FieldSpec("data_product_qualified_name", required=True, type="str"),
            FieldSpec("relationship_type",           required=False, type="str"),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        results = {"success": 0, "errors": []}
        for row in rows:
            try:
                asset_guid = ctx.entity_repo.get_guid(
                    row["asset_qualified_name"], row["asset_type"]
                )
                product_guid = ctx.data_product_repo.get_guid(
                    row["data_product_qualified_name"]
                )
                rel_type = row.get("relationship_type") or ASSET_PRODUCT_RELATIONSHIP

                ctx.relationship_repo.create(
                    type_name=rel_type,
                    end1_guid=product_guid, end1_type="DataProduct",
                    end2_guid=asset_guid,   end2_type=row["asset_type"],
                )
                results["success"] += 1
            except Exception as e:
                results["errors"].append({
                    "asset": row["asset_qualified_name"],
                    "product": row["data_product_qualified_name"],
                    "error": str(e),
                })
        return results
