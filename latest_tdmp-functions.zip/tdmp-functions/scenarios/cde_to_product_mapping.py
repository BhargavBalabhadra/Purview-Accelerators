"""Scenario 5: Map Critical Data Elements to Data Products via Atlas relationships."""
from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


CDE_PRODUCT_RELATIONSHIP = "DataProductCDERelationship"


@register
class CDEToProductMappingScenario(ScenarioBase):
    name             = "cde_to_product_mapping"
    default_template = "cde_to_product_mapping.xlsx"
    schema = Schema(
        name="cde_to_product_mapping",
        fields=[
            FieldSpec("cde_qualified_name",          required=True, type="str"),
            FieldSpec("data_product_qualified_name", required=True, type="str"),
            FieldSpec("relationship_type",           required=False, type="str"),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        results = {"success": 0, "errors": []}
        for row in rows:
            try:
                cde_guid = ctx.cde_repo.get_guid(row["cde_qualified_name"])
                product_guid = ctx.data_product_repo.get_guid(
                    row["data_product_qualified_name"]
                )
                rel_type = row.get("relationship_type") or CDE_PRODUCT_RELATIONSHIP

                ctx.relationship_repo.create(
                    type_name=rel_type,
                    end1_guid=product_guid, end1_type="DataProduct",
                    end2_guid=cde_guid,     end2_type="CriticalDataElement",
                )
                results["success"] += 1
            except Exception as e:
                results["errors"].append({
                    "cde": row["cde_qualified_name"],
                    "product": row["data_product_qualified_name"],
                    "error": str(e),
                })
        return results
