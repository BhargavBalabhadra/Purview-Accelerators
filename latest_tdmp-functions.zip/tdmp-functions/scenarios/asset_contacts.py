"""Scenario 4: Bulk update data asset contacts (Owners and Experts)."""
from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register
from platform.logging_setup import get_logger

log = get_logger(__name__)


@register
class AssetContactsScenario(ScenarioBase):
    name             = "asset_contacts"
    default_template = "asset_contacts.xlsx"
    schema = Schema(
        name="asset_contacts",
        fields=[
            FieldSpec("qualified_name", required=True, type="str"),
            FieldSpec("asset_type",     required=True, type="str"),
            FieldSpec("contact_email",  required=True, type="email"),
            FieldSpec("contact_type",   required=True, type="str",
                      enum=["Expert", "Owner"]),
            FieldSpec("info",           required=False, type="str", max_length=200),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        results = {"success": 0, "errors": []}
        for row in rows:
            try:
                guid = ctx.entity_repo.get_guid(row["qualified_name"], row["asset_type"])
                ctx.contacts_repo.add_contact(
                    guid=guid,
                    email_or_object_id=row["contact_email"],
                    contact_type=row["contact_type"],
                    info=row.get("info", ""),
                )
                results["success"] += 1
            except Exception as e:
                results["errors"].append({
                    "qualified_name": row["qualified_name"],
                    "error": str(e),
                })
        return results
