"""
Excel I/O — read templates from bytes, parse to dicts, support batched windows.
Schema validation lives in platform/validation.py — this just deals with bytes.
"""
import io
import openpyxl

from platform.exceptions import ValidationError
from platform.logging_setup import get_logger
from platform.validation import Schema

log = get_logger(__name__)


def parse_excel(
    excel_bytes: bytes,
    schema: Schema,
    batch_start: int = 0,
    batch_size:  int = 100,
) -> tuple[list[dict], bool, list[str]]:
    """
    Parses a window of rows from an Excel workbook against a Schema.

    Returns:
        (rows, has_more, errors)
        rows     — list of dicts with coerced values
        has_more — True if more rows remain past this batch
        errors   — list of human-readable per-row errors (does NOT raise)
    """
    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), read_only=True, data_only=True)
    ws = wb.active

    all_rows = list(ws.iter_rows(values_only=True))
    wb.close()

    if not all_rows:
        raise ValidationError("Excel template is empty.")

    raw_headers = all_rows[0]
    headers = [
        str(h).strip().lower().replace(" ", "_") if h else ""
        for h in raw_headers
    ]

    header_errs = schema.header_errors(headers)
    if header_errs:
        raise ValidationError(
            f"Excel header is invalid for schema '{schema.name}'",
            errors=header_errs,
        )

    data_rows = []
    for excel_row_num, row in enumerate(all_rows[1:], start=2):
        if all(cell is None or str(cell).strip() == "" for cell in row):
            continue
        row_dict = {h: row[i] if i < len(row) else None for i, h in enumerate(headers)}
        data_rows.append((excel_row_num, row_dict))

    window = data_rows[batch_start: batch_start + batch_size]
    has_more = (batch_start + batch_size) < len(data_rows)

    parsed, errors = [], []
    for excel_row_num, row_dict in window:
        coerced, row_errs = schema.parse_row(row_dict, excel_row_num)
        if row_errs:
            errors.extend(row_errs)
        else:
            coerced["_excel_row"] = excel_row_num
            parsed.append(coerced)

    log.info(
        f"parse_excel scenario={schema.name} batch_start={batch_start} "
        f"window={len(parsed)} total_data_rows={len(data_rows)} "
        f"has_more={has_more} parse_errors={len(errors)}"
    )
    return parsed, has_more, errors


def schema_only_check(excel_bytes: bytes, schema: Schema) -> list[str]:
    """Cheap schema-only check — used by the HTTP trigger before queuing."""
    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), read_only=True, data_only=True)
    ws = wb.active
    first_row = next(ws.iter_rows(values_only=True), None)
    wb.close()

    if not first_row:
        return [f"Template is empty (no header row)"]

    headers = [
        str(h).strip().lower().replace(" ", "_") if h else ""
        for h in first_row
    ]
    return schema.header_errors(headers)
