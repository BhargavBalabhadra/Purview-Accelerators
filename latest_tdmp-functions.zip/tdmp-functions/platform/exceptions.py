"""
Platform exception hierarchy.
Every exception in TDMP inherits from TDMPError so handlers can catch broadly.
"""


class TDMPError(Exception):
    """Base class for all TDMP platform errors."""


class ValidationError(TDMPError):
    """Raised when input data fails schema or business validation."""

    def __init__(self, message: str, errors: list = None):
        super().__init__(message)
        self.errors = errors or []


class ConfigurationError(TDMPError):
    """Raised when required config or env vars are missing or malformed."""


class ResourceNotFoundError(TDMPError):
    """A required Purview resource (entity, collection, type) does not exist."""


class PurviewAPIError(TDMPError):
    """Wraps an underlying Purview/Atlas API failure with context."""

    def __init__(self, message: str, status_code: int = None, response_body: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class StorageError(TDMPError):
    """Blob or queue operation failed."""


class ScenarioRegistrationError(TDMPError):
    """A scenario plugin failed to register correctly."""
