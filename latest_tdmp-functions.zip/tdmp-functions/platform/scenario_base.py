"""
ScenarioBase — the contract every scenario plugin implements.

A scenario provides:
  - name           : URL slug + queue routing key
  - default_template: Excel filename (when the user doesn't override)
  - schema         : Excel column spec (FieldSpec list)
  - run(rows, repos): the actual Purview operation

The platform handles everything else: blob download, Excel parsing,
validation, batching, error reporting, dead-lettering.
"""
from dataclasses import dataclass
from platform.validation import Schema


@dataclass
class ScenarioContext:
    """Bundle passed to scenario.run() — gives access to all repositories."""
    entity_repo:         "EntityRepository"
    relationship_repo:   "RelationshipRepository"
    classification_repo: "ClassificationRepository"
    contacts_repo:       "ContactsRepository"
    collection_repo:     "CollectionRepository"
    domain_repo:         "DomainRepository"
    data_product_repo:   "DataProductRepository"
    cde_repo:            "CDERepository"
    label_repo:          "LabelRepository"
    collection_name:     str = ""


class ScenarioBase:
    """Abstract base — concrete scenarios subclass this."""

    name:             str    = ""
    default_template: str    = ""
    schema:           Schema = None

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        """
        Override this in your scenario.
        Returns: {"success": int, "errors": [{...}, ...]}

        rows are already validated and type-coerced — no extra parsing needed.
        Each row dict has '_excel_row' key with the source row number.
        """
        raise NotImplementedError(f"{self.__class__.__name__} must implement run()")
