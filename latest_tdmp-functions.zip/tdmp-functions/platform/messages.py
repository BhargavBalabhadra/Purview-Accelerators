"""
Platform-level messages — what flows between HTTP trigger and queue trigger.
"""
import json
from dataclasses import dataclass, asdict


@dataclass
class QueueMessage:
    scenario:        str
    template_file:   str
    collection_name: str
    folder_name:     str
    batch_start:     int = 0
    batch_size:      int = 100
    run_id:          str = ""

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, raw: str) -> "QueueMessage":
        return cls(**json.loads(raw))
