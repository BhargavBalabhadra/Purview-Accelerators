"""
Plugin auto-discovery. Scenarios register themselves via @register decorator.
function_app.py imports the scenarios package once at startup and the registry
is populated.
"""
from platform.exceptions import ScenarioRegistrationError
from platform.scenario_base import ScenarioBase


_registry: dict[str, ScenarioBase] = {}


def register(scenario_cls: type[ScenarioBase]) -> type[ScenarioBase]:
    """Decorator: @register on a ScenarioBase subclass adds it to the registry."""
    if not issubclass(scenario_cls, ScenarioBase):
        raise ScenarioRegistrationError(
            f"{scenario_cls.__name__} must inherit from ScenarioBase"
        )

    instance = scenario_cls()

    if not instance.name:
        raise ScenarioRegistrationError(
            f"{scenario_cls.__name__}.name must be set"
        )
    if instance.schema is None:
        raise ScenarioRegistrationError(
            f"{scenario_cls.__name__}.schema must be set"
        )

    if instance.name in _registry:
        raise ScenarioRegistrationError(
            f"Duplicate scenario name: '{instance.name}'"
        )

    _registry[instance.name] = instance
    return scenario_cls


def get(name: str) -> ScenarioBase:
    if name not in _registry:
        raise KeyError(
            f"Unknown scenario '{name}'. Registered: {list(_registry)}"
        )
    return _registry[name]


def all_scenarios() -> dict[str, ScenarioBase]:
    return dict(_registry)


def discover() -> int:
    """Imports the scenarios package, triggering @register on each module.
    Returns count of scenarios registered."""
    import importlib
    import pkgutil
    import scenarios

    for _, modname, _ in pkgutil.iter_modules(scenarios.__path__):
        if not modname.startswith("_"):
            importlib.import_module(f"scenarios.{modname}")

    return len(_registry)
