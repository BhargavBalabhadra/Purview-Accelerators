"""
Result reporter — builds the structured JSON report written to blob.
The same structure is used as the HTTP response body.
"""
import json
from datetime import datetime, timezone


def build_report(
    scenario_name:     str,
    result:            dict,
    run_id:            str = "",
    batch_start:       int = 0,
    has_more:          bool = False,
    parse_errors:      list = None,
    report_blob_path:  str = "",
) -> str:
    parse_errors = parse_errors or []
    runtime_errors = result.get("errors", [])
    succeeded = result.get("success", 0)
    total = succeeded + len(runtime_errors) + len(parse_errors)

    if not runtime_errors and not parse_errors:
        status = "COMPLETED"
    elif succeeded == 0:
        status = "FAILED"
    else:
        status = "COMPLETED_WITH_ERRORS"

    payload = {
        "run_id":     run_id,
        "scenario":   scenario_name,
        "status":     status,
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "batch": {
            "start":            batch_start,
            "processed":        total,
            "has_more_batches": has_more,
        },
        "summary": {
            "total_rows":   total,
            "succeeded":    succeeded,
            "failed":       len(runtime_errors),
            "parse_errors": len(parse_errors),
        },
        "parse_errors":   parse_errors[:50],
        "runtime_errors": runtime_errors[:50],
        "report_blob":    report_blob_path,
    }

    return json.dumps(payload, indent=2, default=str)
