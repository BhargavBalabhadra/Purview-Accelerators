"""
Blob storage operations — folder validation, download, report writing,
dead-letter archive, completed-template archive.
All paths are relative to the configured BLOB_CONTAINER_NAME.
"""
from datetime import datetime, timezone
from azure.storage.blob import BlobServiceClient
from azure.identity import DefaultAzureCredential

from platform.config import get_settings
from platform.exceptions import StorageError
from platform.logging_setup import get_logger

log = get_logger(__name__)


def _service() -> BlobServiceClient:
    settings = get_settings()
    return BlobServiceClient(
        account_url=f"https://{settings.storage_account_name}.blob.core.windows.net",
        credential=DefaultAzureCredential(),
    )


def folder_exists(folder_name: str) -> bool:
    settings = get_settings()
    client = _service().get_container_client(settings.blob_container_name)
    blobs = list(client.list_blobs(name_starts_with=f"{folder_name}/", results_per_page=5))
    return len(blobs) > 0


def download_template(folder_name: str, blob_name: str) -> bytes:
    settings = get_settings()
    full_path = f"{folder_name}/{blob_name}"
    blob = _service().get_blob_client(
        container=settings.blob_container_name,
        blob=full_path,
    )
    if not blob.exists():
        raise StorageError(f"Template not found: {settings.blob_container_name}/{full_path}")
    data = blob.download_blob().readall()
    log.info(f"download_template path={full_path} bytes={len(data)}")
    return data


def write_report(run_id: str, scenario: str, report_json: str) -> str:
    settings = get_settings()
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    blob_path = f"{settings.blob_reports_folder}/{scenario}_{run_id}_{ts}.json"
    _service().get_blob_client(
        container=settings.blob_container_name, blob=blob_path
    ).upload_blob(report_json.encode("utf-8"), overwrite=True)
    log.info(f"write_report path={blob_path}")
    return blob_path


def write_failed_message(run_id: str, message_body: str, error: str) -> str:
    import json
    settings = get_settings()
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    blob_path = f"{settings.blob_failed_folder}/{run_id}_{ts}.json"
    payload = json.dumps({
        "run_id": run_id,
        "timestamp": ts,
        "error": error,
        "original_message": message_body,
    }, indent=2)
    _service().get_blob_client(
        container=settings.blob_container_name, blob=blob_path
    ).upload_blob(payload.encode("utf-8"), overwrite=True)
    log.warning(f"write_failed_message path={blob_path}")
    return blob_path


def archive_template(folder_name: str, blob_name: str) -> str:
    settings = get_settings()
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    src = f"{folder_name}/{blob_name}"
    stem = blob_name.rsplit(".", 1)[0]
    dest = f"{settings.blob_completed_folder}/{stem}_{ts}.xlsx"

    src_url = (
        f"https://{settings.storage_account_name}.blob.core.windows.net/"
        f"{settings.blob_container_name}/{src}"
    )
    dest_blob = _service().get_blob_client(
        container=settings.blob_container_name, blob=dest
    )
    dest_blob.start_copy_from_url(src_url)
    _service().get_blob_client(
        container=settings.blob_container_name, blob=src
    ).delete_blob()
    log.info(f"archive_template src={src} dest={dest}")
    return dest
