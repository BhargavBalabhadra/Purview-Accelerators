"""
Dead-letter alerting. Logs critical record (App Insights alert rule trigger).
Email via Azure Communication Services if ACS_CONNECTION_STRING is set.
"""
import os
from platform.config import get_settings
from platform.logging_setup import get_logger

log = get_logger(__name__)


def send_failure_alert(run_id: str, scenario: str, error: str, blob_path: str) -> None:
    settings = get_settings()
    subject = f"[TDMP] Dead-letter — {scenario} — run_id={run_id}"
    body = (
        f"Scenario: {scenario}\n"
        f"Run ID: {run_id}\n"
        f"Error: {error}\n"
        f"Failed message archived at: {blob_path}\n\n"
        f"Action: review the failed blob and re-trigger if needed."
    )

    acs_connection = os.environ.get("ACS_CONNECTION_STRING", "")

    if acs_connection and settings.alert_email:
        try:
            from azure.communication.email import EmailClient
            client = EmailClient.from_connection_string(acs_connection)
            client.begin_send({
                "senderAddress": "noreply@tdmp-alerts.azurecomm.net",
                "recipients": {"to": [{"address": settings.alert_email}]},
                "content": {"subject": subject, "plainText": body},
            }).result()
            log.info(f"Alert email sent to {settings.alert_email}")
            return
        except Exception as e:
            log.error(f"Email send failed: {e}")

    log.critical(
        f"TDMP_DEAD_LETTER run_id={run_id} scenario={scenario} "
        f"error={error} blob={blob_path}"
    )
