"""
Structured logging wrapper. Every log emitted by TDMP carries:
  - run_id      (correlates across queue chains)
  - scenario    (which scenario is running)
  - batch_index (which batch within a run)
These appear as custom dimensions in App Insights.
"""
import logging
from contextvars import ContextVar


_run_id      : ContextVar[str] = ContextVar("run_id",      default="")
_scenario    : ContextVar[str] = ContextVar("scenario",    default="")
_batch_index : ContextVar[int] = ContextVar("batch_index", default=0)


def set_log_context(run_id: str = "", scenario: str = "", batch_index: int = 0) -> None:
    if run_id:
        _run_id.set(run_id)
    if scenario:
        _scenario.set(scenario)
    _batch_index.set(batch_index)


def clear_log_context() -> None:
    _run_id.set("")
    _scenario.set("")
    _batch_index.set(0)


class TDMPContextFilter(logging.Filter):
    """Injects run_id, scenario, batch_index as record attributes."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.run_id      = _run_id.get()
        record.scenario    = _scenario.get()
        record.batch_index = _batch_index.get()
        return True


def get_logger(name: str) -> logging.LogRecord:
    """Returns a logger that emits structured records with TDMP context."""
    logger = logging.getLogger(name)
    if not any(isinstance(f, TDMPContextFilter) for f in logger.filters):
        logger.addFilter(TDMPContextFilter())
    return logger
