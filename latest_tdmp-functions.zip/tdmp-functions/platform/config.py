"""
Centralised configuration access.
All env-var reads go through here so misconfiguration is caught at startup,
and so we can swap to Key Vault / config file sources later without changing callers.
"""
import os
from dataclasses import dataclass

from platform.exceptions import ConfigurationError


@dataclass(frozen=True)
class Settings:
    purview_account_name:    str
    storage_account_name:    str
    blob_container_name:     str
    blob_template_folder:    str
    blob_reports_folder:     str
    blob_failed_folder:      str
    blob_completed_folder:   str
    queue_name:              str
    poison_queue_name:       str
    batch_size:              int
    alert_email:             str = ""
    keyvault_url:            str = ""

    @classmethod
    def from_env(cls) -> "Settings":
        missing = []

        def _req(name: str) -> str:
            val = os.environ.get(name, "").strip()
            if not val:
                missing.append(name)
            return val

        purview_account = _req("PURVIEW_ACCOUNT_NAME")
        storage_account = _req("STORAGE_ACCOUNT_NAME")
        container       = _req("BLOB_CONTAINER_NAME")
        queue_name      = _req("QUEUE_NAME")

        if missing:
            raise ConfigurationError(
                f"Missing required environment variables: {missing}"
            )

        return cls(
            purview_account_name  = purview_account,
            storage_account_name  = storage_account,
            blob_container_name   = container,
            blob_template_folder  = os.environ.get("BLOB_TEMPLATE_FOLDER",  "templates"),
            blob_reports_folder   = os.environ.get("BLOB_REPORTS_FOLDER",   "reports"),
            blob_failed_folder    = os.environ.get("BLOB_FAILED_FOLDER",    "failed"),
            blob_completed_folder = os.environ.get("BLOB_COMPLETED_FOLDER", "completed"),
            queue_name            = queue_name,
            poison_queue_name     = os.environ.get("POISON_QUEUE_NAME",     f"{queue_name}-poison"),
            batch_size            = int(os.environ.get("BATCH_SIZE", "100")),
            alert_email           = os.environ.get("ALERT_EMAIL", ""),
            keyvault_url          = os.environ.get("KEYVAULT_URL", ""),
        )


_settings: Settings | None = None


def get_settings() -> Settings:
    """Lazy singleton — Settings.from_env() runs once and is cached."""
    global _settings
    if _settings is None:
        _settings = Settings.from_env()
    return _settings


def reset_settings_for_testing() -> None:
    """Test helper — forces re-reading env vars on next get_settings() call."""
    global _settings
    _settings = None
