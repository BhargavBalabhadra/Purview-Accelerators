"""
Storage queue operations.
Encodes JSON messages as base64 (Azure Functions queue-trigger expectation)
and provides a chain-enqueue helper for batched scenarios.
"""
import base64
from azure.storage.queue import QueueClient
from azure.identity import DefaultAzureCredential

from platform.config import get_settings
from platform.logging_setup import get_logger

log = get_logger(__name__)


def _client(queue_name: str = None) -> QueueClient:
    settings = get_settings()
    return QueueClient(
        account_url=f"https://{settings.storage_account_name}.queue.core.windows.net",
        queue_name=queue_name or settings.queue_name,
        credential=DefaultAzureCredential(),
    )


def enqueue(message_json: str, queue_name: str = None) -> str:
    encoded = base64.b64encode(message_json.encode("utf-8")).decode("utf-8")
    result = _client(queue_name).send_message(encoded)
    log.info(f"enqueue id={result.id} queue={queue_name or 'default'}")
    return result.id


def queue_depth(queue_name: str = None) -> int:
    """Returns approximate message count — used by the ADO pipeline drain check."""
    props = _client(queue_name).get_queue_properties()
    return props.approximate_message_count or 0
