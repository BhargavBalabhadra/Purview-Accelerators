"""
Declarative validation engine.

Each scenario declares an Excel schema as a list of FieldSpec.
The engine:
  1. Validates required columns are present in the header row
  2. Type-coerces values
  3. Runs per-row constraint checks (regex, enum, length, custom)
  4. Reports errors with row numbers so users know what to fix

This is what gives us 'scenarios fail with clear errors' instead of cryptic stack traces.
"""
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
import re


@dataclass
class FieldSpec:
    name:          str
    required:      bool   = True
    type:          str    = "str"     # "str" | "int" | "email" | "semicolon_list"
    enum:          list   = field(default_factory=list)
    regex:         str    = ""
    max_length:    int    = 0
    description:   str    = ""

    def coerce_and_validate(self, raw: Any, row_num: int) -> tuple[Any, Optional[str]]:
        """Returns (coerced_value, error_message_or_None)."""
        if raw is None or str(raw).strip() == "":
            if self.required:
                return None, f"Row {row_num}: '{self.name}' is required but blank"
            return "", None

        val = str(raw).strip()

        if self.max_length and len(val) > self.max_length:
            return None, (
                f"Row {row_num}: '{self.name}' exceeds max length "
                f"{self.max_length} ({len(val)} chars)"
            )

        if self.regex and not re.match(self.regex, val):
            return None, (
                f"Row {row_num}: '{self.name}' value '{val[:40]}' "
                f"does not match required pattern"
            )

        if self.type == "int":
            try:
                return int(float(val)), None
            except ValueError:
                return None, f"Row {row_num}: '{self.name}' must be an integer, got '{val}'"

        if self.type == "email":
            if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", val):
                return None, f"Row {row_num}: '{self.name}' is not a valid email: '{val}'"

        if self.type == "semicolon_list":
            return [item.strip() for item in val.split(";") if item.strip()], None

        if self.enum and val not in self.enum:
            return None, (
                f"Row {row_num}: '{self.name}' value '{val}' "
                f"not in allowed values: {self.enum}"
            )

        return val, None


@dataclass
class Schema:
    name:   str
    fields: list[FieldSpec]

    @property
    def required_columns(self) -> list[str]:
        return [f.name for f in self.fields if f.required]

    @property
    def all_columns(self) -> list[str]:
        return [f.name for f in self.fields]

    def header_errors(self, headers: list[str]) -> list[str]:
        norm = [h.strip().lower().replace(" ", "_") if h else "" for h in headers]
        return [
            f"Missing required column: '{col}'"
            for col in self.required_columns
            if col not in norm
        ]

    def parse_row(self, row: dict, row_num: int) -> tuple[dict, list[str]]:
        out, errors = {}, []
        for spec in self.fields:
            raw = row.get(spec.name)
            value, err = spec.coerce_and_validate(raw, row_num)
            if err:
                errors.append(err)
            else:
                out[spec.name] = value
        return out, errors
