# Integration tests

Tests in this folder run against a real Purview account. They are NOT run
in the build pipeline because they require live credentials.

To run locally against your dev environment:

```bash
export PURVIEW_ACCOUNT_NAME=<your-dev-account>
export STORAGE_ACCOUNT_NAME=<your-dev-storage>
export BLOB_CONTAINER_NAME=<your-dev-container>
export QUEUE_NAME=tdmp-test-queue

az login

PYTHONPATH=. .venv/bin/pytest tests/integration -v
```

Skeleton template for a new integration test:

```python
import os, pytest

# Skip these tests if env not configured
pytestmark = pytest.mark.skipif(
    not os.environ.get("PURVIEW_ACCOUNT_NAME"),
    reason="Integration env not configured",
)

def test_collection_lookup_against_real_purview():
    from adapters.purview_client import get_purview_client
    from domain.collection_repository import CollectionRepository
    repo = CollectionRepository(get_purview_client())
    assert repo.exists("root") is True
```
