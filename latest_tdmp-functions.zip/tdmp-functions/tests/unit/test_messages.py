"""Tests for QueueMessage serialisation."""
from platform.messages import QueueMessage


def test_roundtrip():
    m = QueueMessage(
        scenario="asset_descriptions",
        template_file="t.xlsx",
        collection_name="root",
        folder_name="templates",
        batch_start=200, batch_size=100, run_id="abc",
    )
    restored = QueueMessage.from_json(m.to_json())
    assert restored == m


def test_defaults():
    m = QueueMessage("s", "t.xlsx", "c", "f")
    assert m.batch_start == 0
    assert m.batch_size == 100
    assert m.run_id == ""
