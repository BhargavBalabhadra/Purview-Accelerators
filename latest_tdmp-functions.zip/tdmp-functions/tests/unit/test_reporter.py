"""Tests for the report builder."""
import json
from platform.reporter import build_report


def test_completed_status_when_no_errors():
    body = json.loads(build_report("scn", {"success": 5, "errors": []}, run_id="r1"))
    assert body["status"] == "COMPLETED"


def test_failed_status_when_no_successes():
    body = json.loads(build_report(
        "scn",
        {"success": 0, "errors": [{"x": "err"}]},
        parse_errors=["bad row"],
    ))
    assert body["status"] == "FAILED"


def test_completed_with_errors_when_partial():
    body = json.loads(build_report(
        "scn",
        {"success": 3, "errors": [{"x": "e1"}]},
    ))
    assert body["status"] == "COMPLETED_WITH_ERRORS"


def test_summary_counts_correct():
    body = json.loads(build_report(
        "scn",
        {"success": 5, "errors": [{"x": "e"}, {"y": "f"}]},
        parse_errors=["bad row 1"],
    ))
    s = body["summary"]
    assert s["succeeded"] == 5
    assert s["failed"] == 2
    assert s["parse_errors"] == 1
    assert s["total_rows"] == 8


def test_batch_metadata_populated():
    body = json.loads(build_report(
        "scn", {"success": 5, "errors": []},
        run_id="abc", batch_start=200, has_more=True,
    ))
    assert body["batch"]["start"] == 200
    assert body["batch"]["has_more_batches"] is True
    assert body["run_id"] == "abc"
