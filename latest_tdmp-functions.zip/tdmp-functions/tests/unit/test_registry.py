"""Tests for the scenario registry — auto-discovery and registration."""
import pytest

from platform.registry import register, get, all_scenarios, _registry
from platform.scenario_base import ScenarioBase
from platform.validation import Schema, FieldSpec
from platform.exceptions import ScenarioRegistrationError


def setup_function():
    _registry.clear()


def test_register_adds_to_registry():
    @register
    class FooScenario(ScenarioBase):
        name = "foo"
        schema = Schema(name="foo", fields=[FieldSpec("x")])

    assert "foo" in all_scenarios()


def test_register_rejects_non_scenario_class():
    with pytest.raises(ScenarioRegistrationError):
        @register
        class NotAScenario:
            name = "x"
            schema = Schema(name="x", fields=[FieldSpec("a")])


def test_register_rejects_missing_name():
    with pytest.raises(ScenarioRegistrationError):
        @register
        class NoName(ScenarioBase):
            schema = Schema(name="x", fields=[FieldSpec("a")])


def test_register_rejects_missing_schema():
    with pytest.raises(ScenarioRegistrationError):
        @register
        class NoSchema(ScenarioBase):
            name = "noschema"


def test_register_rejects_duplicates():
    @register
    class A(ScenarioBase):
        name = "dup"
        schema = Schema(name="dup", fields=[FieldSpec("a")])
    with pytest.raises(ScenarioRegistrationError):
        @register
        class B(ScenarioBase):
            name = "dup"
            schema = Schema(name="dup", fields=[FieldSpec("a")])


def test_get_unknown_scenario_raises():
    with pytest.raises(KeyError):
        get("nonexistent")


def test_all_seven_scenarios_register():
    """Smoke test: importing all scenarios should populate exactly 7."""
    _registry.clear()
    from platform.registry import discover
    count = discover()
    assert count == 7
    assert set(all_scenarios()) == {
        "asset_classifications",
        "asset_labels",
        "asset_descriptions",
        "asset_contacts",
        "cde_to_product_mapping",
        "governance_domains",
        "asset_to_product_mapping",
    }
