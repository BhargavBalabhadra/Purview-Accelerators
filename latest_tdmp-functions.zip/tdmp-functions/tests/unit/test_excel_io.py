"""Tests for parse_excel + schema_only_check using in-memory workbooks."""
import io
import pytest
import openpyxl

from platform.excel_io import parse_excel, schema_only_check
from platform.validation import Schema, FieldSpec
from platform.exceptions import ValidationError


def _build(headers: list, rows: list) -> bytes:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(headers)
    for row in rows:
        ws.append(row)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


SCHEMA = Schema(
    name="t",
    fields=[
        FieldSpec("qualified_name", required=True),
        FieldSpec("description",    required=True, max_length=4000),
    ],
)


def test_schema_only_check_passes():
    data = _build(["qualified_name", "description"], [["q1", "d1"]])
    assert schema_only_check(data, SCHEMA) == []


def test_schema_only_check_fails_on_missing_col():
    data = _build(["qualified_name"], [["q1"]])
    errs = schema_only_check(data, SCHEMA)
    assert len(errs) == 1 and "description" in errs[0]


def test_parse_excel_returns_rows():
    data = _build(["qualified_name", "description"], [
        ["q1", "d1"],
        ["q2", "d2"],
    ])
    rows, has_more, errs = parse_excel(data, SCHEMA, batch_start=0, batch_size=10)
    assert len(rows) == 2 and has_more is False and errs == []
    assert rows[0]["qualified_name"] == "q1"
    assert rows[0]["_excel_row"] == 2  # Excel rows are 1-indexed, header is row 1


def test_parse_excel_batch_window():
    data = _build(
        ["qualified_name", "description"],
        [[f"q{i}", f"d{i}"] for i in range(250)],
    )
    rows1, more1, _ = parse_excel(data, SCHEMA, batch_start=0,   batch_size=100)
    rows2, more2, _ = parse_excel(data, SCHEMA, batch_start=100, batch_size=100)
    rows3, more3, _ = parse_excel(data, SCHEMA, batch_start=200, batch_size=100)
    assert len(rows1) == 100 and more1 is True
    assert len(rows2) == 100 and more2 is True
    assert len(rows3) == 50  and more3 is False


def test_parse_excel_skips_blank_rows():
    data = _build(["qualified_name", "description"], [
        ["q1", "d1"],
        [None, None],
        ["q2", "d2"],
    ])
    rows, _, errs = parse_excel(data, SCHEMA)
    assert len(rows) == 2 and errs == []


def test_parse_excel_collects_row_errors():
    data = _build(["qualified_name", "description"], [
        ["q1", "d1"],
        ["q2", ""],         # blank required field
        ["q3", "d3"],
    ])
    rows, _, errs = parse_excel(data, SCHEMA)
    assert len(rows) == 2  # q2 was rejected, only q1 and q3 returned
    assert len(errs) == 1 and "Row 3" in errs[0]


def test_parse_excel_raises_on_missing_header():
    data = _build(["qualified_name"], [["q1"]])
    with pytest.raises(ValidationError):
        parse_excel(data, SCHEMA)
