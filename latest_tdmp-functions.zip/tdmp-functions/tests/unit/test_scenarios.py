"""
Scenario-level unit tests using mocked repositories.
This is the big payoff of the layered architecture — we can test scenario
business logic without any real Purview, Excel, blob, or queue.
"""
from unittest.mock import MagicMock
import pytest

from platform.registry import discover
from platform.scenario_base import ScenarioContext


@pytest.fixture(scope="module", autouse=True)
def ensure_scenarios_registered():
    discover()


def _mock_ctx() -> ScenarioContext:
    return ScenarioContext(
        entity_repo         = MagicMock(),
        relationship_repo   = MagicMock(),
        classification_repo = MagicMock(),
        contacts_repo       = MagicMock(),
        collection_repo     = MagicMock(),
        domain_repo         = MagicMock(),
        data_product_repo   = MagicMock(),
        cde_repo            = MagicMock(),
        label_repo          = MagicMock(),
        collection_name     = "test",
    )


def test_asset_classifications_groups_per_asset():
    from platform.registry import get
    scenario = get("asset_classifications")
    ctx = _mock_ctx()
    rows = [
        {"qualified_name": "qn1", "asset_type": "t1", "classification_name": "PII", "_excel_row": 2},
        {"qualified_name": "qn1", "asset_type": "t1", "classification_name": "Confidential", "_excel_row": 3},
        {"qualified_name": "qn2", "asset_type": "t1", "classification_name": "Public", "_excel_row": 4},
    ]
    result = scenario.run(rows, ctx)
    # Two distinct assets → two API calls (qn1 batched once with both classifications)
    assert ctx.classification_repo.apply.call_count == 2
    assert result["success"] == 2


def test_asset_descriptions_uses_user_description_fallback():
    from platform.registry import get
    scenario = get("asset_descriptions")
    ctx = _mock_ctx()
    ctx.entity_repo.upsert_bulk.return_value = {"success": 2, "errors": []}
    rows = [
        {"qualified_name": "qn1", "asset_type": "t1", "display_name": "n1",
         "description": "d1", "user_description": "ud1", "_excel_row": 2},
        {"qualified_name": "qn2", "asset_type": "t1", "display_name": "n2",
         "description": "d2", "user_description": "", "_excel_row": 3},
    ]
    scenario.run(rows, ctx)
    sent = ctx.entity_repo.upsert_bulk.call_args[0][0]
    assert sent[0].attributes["userDescription"] == "ud1"
    assert sent[1].attributes["userDescription"] == "d2"  # fallback


def test_asset_contacts_resolves_guid_then_calls_repo():
    from platform.registry import get
    scenario = get("asset_contacts")
    ctx = _mock_ctx()
    ctx.entity_repo.get_guid.return_value = "guid-123"
    rows = [{
        "qualified_name": "qn1", "asset_type": "t1",
        "contact_email": "x@y.com", "contact_type": "Owner",
        "info": "test", "_excel_row": 2,
    }]
    result = scenario.run(rows, ctx)
    ctx.entity_repo.get_guid.assert_called_once_with("qn1", "t1")
    ctx.contacts_repo.add_contact.assert_called_once()
    assert result["success"] == 1


def test_cde_mapping_resolves_both_guids_then_creates_relationship():
    from platform.registry import get
    scenario = get("cde_to_product_mapping")
    ctx = _mock_ctx()
    ctx.cde_repo.get_guid.return_value = "cde-guid"
    ctx.data_product_repo.get_guid.return_value = "product-guid"
    rows = [{
        "cde_qualified_name": "cde://x", "data_product_qualified_name": "dp://y",
        "relationship_type": "", "_excel_row": 2,
    }]
    scenario.run(rows, ctx)
    ctx.relationship_repo.create.assert_called_once()
    call = ctx.relationship_repo.create.call_args
    assert call.kwargs["end1_guid"] == "product-guid"
    assert call.kwargs["end2_guid"] == "cde-guid"


def test_scenario_collects_runtime_errors():
    from platform.registry import get
    scenario = get("asset_contacts")
    ctx = _mock_ctx()
    ctx.entity_repo.get_guid.side_effect = Exception("entity not found")
    rows = [{
        "qualified_name": "qn1", "asset_type": "t1",
        "contact_email": "x@y.com", "contact_type": "Owner",
        "info": "", "_excel_row": 2,
    }]
    result = scenario.run(rows, ctx)
    assert result["success"] == 0
    assert len(result["errors"]) == 1
    assert "entity not found" in result["errors"][0]["error"]
