"""Unit tests for the declarative validation engine."""
import pytest
from platform.validation import FieldSpec, Schema


def test_required_field_blank_returns_error():
    spec = FieldSpec("name", required=True)
    val, err = spec.coerce_and_validate("", row_num=2)
    assert val is None
    assert "required" in err.lower()
    assert "row 2" in err.lower()


def test_optional_field_blank_returns_empty():
    spec = FieldSpec("nickname", required=False)
    val, err = spec.coerce_and_validate("", row_num=2)
    assert val == ""
    assert err is None


def test_max_length_violation():
    spec = FieldSpec("desc", max_length=10)
    val, err = spec.coerce_and_validate("this string is far too long", row_num=3)
    assert val is None
    assert "max length" in err.lower()


def test_email_type_validates():
    spec = FieldSpec("email", type="email")
    _, err1 = spec.coerce_and_validate("alice@example.com", row_num=1)
    assert err1 is None
    _, err2 = spec.coerce_and_validate("not-an-email", row_num=1)
    assert err2 and "valid email" in err2


def test_int_type_coerces():
    spec = FieldSpec("count", type="int")
    val, err = spec.coerce_and_validate("42", row_num=1)
    assert val == 42 and err is None


def test_int_type_rejects_text():
    spec = FieldSpec("count", type="int")
    _, err = spec.coerce_and_validate("twelve", row_num=5)
    assert err and "integer" in err


def test_enum_validates():
    spec = FieldSpec("status", enum=["draft", "published", "deprecated"])
    _, err = spec.coerce_and_validate("draft", row_num=1)
    assert err is None
    _, err2 = spec.coerce_and_validate("archived", row_num=1)
    assert err2 and "not in allowed" in err2


def test_semicolon_list_splits():
    spec = FieldSpec("tags", type="semicolon_list")
    val, err = spec.coerce_and_validate("a; b ; c", row_num=1)
    assert val == ["a", "b", "c"] and err is None


def test_regex_pattern_enforced():
    spec = FieldSpec("qn", regex=r"^[a-z]+://")
    _, err = spec.coerce_and_validate("not-a-uri", row_num=1)
    assert err and "pattern" in err


def test_schema_header_errors_detect_missing():
    schema = Schema(
        name="t",
        fields=[
            FieldSpec("a", required=True),
            FieldSpec("b", required=True),
            FieldSpec("c", required=False),
        ],
    )
    errs = schema.header_errors(["a", "c"])
    assert len(errs) == 1 and "b" in errs[0]


def test_schema_parse_row_collects_all_errors():
    schema = Schema(
        name="t",
        fields=[
            FieldSpec("name",  required=True, type="str"),
            FieldSpec("email", required=True, type="email"),
            FieldSpec("count", required=True, type="int"),
        ],
    )
    parsed, errs = schema.parse_row(
        {"name": "", "email": "bad-email", "count": "xyz"}, row_num=7,
    )
    assert len(errs) == 3
