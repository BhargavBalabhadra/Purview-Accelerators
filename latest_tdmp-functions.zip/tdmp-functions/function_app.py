"""
TDMP Purview Automation Platform — Azure Function App entry point.

Functions:
  1. http_trigger          POST /api/purview/{scenario}    enqueue a run
  2. queue_trigger         queue: tdmp-upload-queue        process a batch
  3. dead_letter_monitor   queue: tdmp-upload-queue-poison alert + archive
  4. health_check          GET  /api/health                liveness probe
"""
import json
import uuid
import base64
import concurrent.futures

import azure.functions as func

from platform.config         import get_settings
from platform.logging_setup  import get_logger, set_log_context, clear_log_context
from platform.exceptions     import (
    TDMPError, ValidationError, ResourceNotFoundError, StorageError,
)
from platform.messages       import QueueMessage
from platform.registry       import discover, get as get_scenario, all_scenarios
from platform.scenario_base  import ScenarioContext
from platform.blob_io        import (
    folder_exists, download_template, write_report,
    write_failed_message, archive_template,
)
from platform.queue_io       import enqueue
from platform.excel_io       import parse_excel, schema_only_check
from platform.reporter       import build_report
from platform.notifier       import send_failure_alert

from adapters.purview_client            import get_purview_client
from domain.entity_repository           import EntityRepository
from domain.relationship_repository     import RelationshipRepository
from domain.classification_repository   import ClassificationRepository
from domain.contacts_repository         import ContactsRepository
from domain.collection_repository       import CollectionRepository
from domain.domain_repository           import DomainRepository
from domain.data_product_repository     import DataProductRepository
from domain.cde_repository              import CDERepository
from domain.label_repository            import LabelRepository

# ── Auto-discover all @register'd scenarios at import time ───────────────────
SCENARIO_COUNT = discover()

log = get_logger(__name__)
log.info(f"Registered {SCENARIO_COUNT} scenario(s): {list(all_scenarios())}")

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


def _build_context(collection_name: str = "") -> ScenarioContext:
    """Wires up all repositories with a shared PurviewClient."""
    client = get_purview_client()
    entity_repo = EntityRepository(client)
    return ScenarioContext(
        entity_repo         = entity_repo,
        relationship_repo   = RelationshipRepository(client),
        classification_repo = ClassificationRepository(client),
        contacts_repo       = ContactsRepository(client),
        collection_repo     = CollectionRepository(client),
        domain_repo         = DomainRepository(entity_repo),
        data_product_repo   = DataProductRepository(entity_repo),
        cde_repo            = CDERepository(entity_repo),
        label_repo          = LabelRepository(client),
        collection_name     = collection_name,
    )


def _error_response(status: int, message: str, details: list = None) -> func.HttpResponse:
    body = {"status": status, "error": message}
    if details:
        body["details"] = details
    log.warning(f"http {status}: {message}")
    return func.HttpResponse(
        json.dumps(body, indent=2),
        mimetype="application/json",
        status_code=status,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Function 1: HTTP Trigger
# ─────────────────────────────────────────────────────────────────────────────
@app.route(route="purview/{scenario}", methods=["POST"])
def http_trigger(req: func.HttpRequest) -> func.HttpResponse:
    scenario_name   = req.route_params.get("scenario", "")
    collection_name = req.params.get("collection", "")
    folder_name     = req.params.get("folder", "")

    set_log_context(scenario=scenario_name)

    # ── Validate scenario name via registry ──────────────────────────────────
    try:
        scenario = get_scenario(scenario_name)
    except KeyError:
        return _error_response(
            400,
            f"Unknown scenario '{scenario_name}'",
            details=[f"Valid: {list(all_scenarios())}"],
        )

    template_file = req.params.get("template", scenario.default_template)

    if not collection_name or not folder_name:
        return _error_response(
            400, "Query params 'collection' and 'folder' are required."
        )

    # ── Parallel pre-flight: folder + collection ─────────────────────────────
    ctx = _build_context(collection_name)
    errs: list[str] = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        f_folder = pool.submit(folder_exists, folder_name)
        f_coll   = pool.submit(ctx.collection_repo.exists, collection_name)
        try:
            if not f_folder.result(timeout=20):
                errs.append(f"Folder '{folder_name}' not found in storage container")
        except Exception as e:
            errs.append(f"Folder check failed: {e}")
        try:
            if not f_coll.result(timeout=20):
                errs.append(f"Collection '{collection_name}' not found in Purview")
        except Exception as e:
            errs.append(f"Collection check failed: {e}")

    if errs:
        return _error_response(422, "Pre-flight validation failed", details=errs)

    # ── Excel schema check (cheap header-only read) ──────────────────────────
    try:
        excel_bytes = download_template(folder_name, template_file)
    except StorageError as e:
        return _error_response(404, str(e))

    schema_errs = schema_only_check(excel_bytes, scenario.schema)
    if schema_errs:
        return _error_response(422, "Excel schema invalid", details=schema_errs)

    # ── Enqueue ──────────────────────────────────────────────────────────────
    settings = get_settings()
    run_id = str(uuid.uuid4())[:8]
    set_log_context(run_id=run_id)

    msg = QueueMessage(
        scenario=scenario_name,
        template_file=template_file,
        collection_name=collection_name,
        folder_name=folder_name,
        batch_size=settings.batch_size,
        run_id=run_id,
    )
    try:
        msg_id = enqueue(msg.to_json())
    except Exception as e:
        return _error_response(500, f"Failed to enqueue: {e}")

    log.info(f"http_trigger queued run_id={run_id} msg_id={msg_id}")
    return func.HttpResponse(
        json.dumps({
            "status": "QUEUED",
            "run_id": run_id,
            "message_id": msg_id,
            "scenario": scenario_name,
            "collection": collection_name,
            "folder": folder_name,
            "template": template_file,
        }, indent=2),
        mimetype="application/json",
        status_code=202,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Function 2: Queue Trigger — processes a batch
# ─────────────────────────────────────────────────────────────────────────────
@app.queue_trigger(
    arg_name="msg",
    queue_name="%QUEUE_NAME%",
    connection="AzureWebJobsStorage",
)
def queue_trigger(msg: func.QueueMessage) -> None:
    raw = msg.get_body().decode("utf-8")
    try:
        raw = base64.b64decode(raw).decode("utf-8")
    except Exception:
        pass  # already plain JSON

    payload = QueueMessage.from_json(raw)
    set_log_context(
        run_id=payload.run_id,
        scenario=payload.scenario,
        batch_index=payload.batch_start // max(payload.batch_size, 1),
    )

    try:
        scenario = get_scenario(payload.scenario)
    except KeyError as e:
        log.error(f"Unknown scenario in queue message: {e}")
        raise

    log.info(f"queue_trigger run_id={payload.run_id} batch_start={payload.batch_start}")

    try:
        excel_bytes = download_template(payload.folder_name, payload.template_file)
    except StorageError as e:
        log.error(f"download failed: {e}")
        raise

    rows, has_more, parse_errors = parse_excel(
        excel_bytes,
        scenario.schema,
        batch_start=payload.batch_start,
        batch_size=payload.batch_size,
    )

    ctx = _build_context(payload.collection_name)

    if rows:
        result = scenario.run(rows, ctx)
    else:
        result = {"success": 0, "errors": []}

    report_json = build_report(
        scenario_name=payload.scenario,
        result=result,
        run_id=payload.run_id,
        batch_start=payload.batch_start,
        has_more=has_more,
        parse_errors=parse_errors,
    )
    report_path = write_report(payload.run_id, payload.scenario, report_json)
    log.info(f"report written path={report_path}")

    if has_more:
        next_msg = QueueMessage(
            scenario=payload.scenario,
            template_file=payload.template_file,
            collection_name=payload.collection_name,
            folder_name=payload.folder_name,
            batch_start=payload.batch_start + payload.batch_size,
            batch_size=payload.batch_size,
            run_id=payload.run_id,
        )
        enqueue(next_msg.to_json())
        log.info(f"chained next batch start={next_msg.batch_start}")
    else:
        try:
            archive_template(payload.folder_name, payload.template_file)
        except Exception as e:
            log.warning(f"archive failed (non-fatal): {e}")

    clear_log_context()


# ─────────────────────────────────────────────────────────────────────────────
# Function 3: Dead-Letter Monitor
# ─────────────────────────────────────────────────────────────────────────────
@app.queue_trigger(
    arg_name="poison_msg",
    queue_name="%POISON_QUEUE_NAME%",
    connection="AzureWebJobsStorage",
)
def dead_letter_monitor(poison_msg: func.QueueMessage) -> None:
    raw = poison_msg.get_body().decode("utf-8")
    try:
        raw = base64.b64decode(raw).decode("utf-8")
    except Exception:
        pass

    log.critical(f"dead_letter raw={raw[:300]}")

    run_id = "unknown"
    scenario = "unknown"
    try:
        data = json.loads(raw)
        run_id = data.get("run_id", "unknown")
        scenario = data.get("scenario", "unknown")
    except Exception:
        pass

    error_msg = "Message exhausted retries (5) and was dead-lettered."
    blob_path = write_failed_message(run_id, raw, error_msg)
    send_failure_alert(run_id, scenario, error_msg, blob_path)


# ─────────────────────────────────────────────────────────────────────────────
# Function 4: Health Check
# ─────────────────────────────────────────────────────────────────────────────
@app.route(route="health", methods=["GET"])
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    settings = get_settings()
    return func.HttpResponse(
        json.dumps({
            "status": "healthy",
            "scenarios_registered": SCENARIO_COUNT,
            "scenarios": list(all_scenarios()),
            "purview_account": settings.purview_account_name,
            "queue": settings.queue_name,
            "batch_size": settings.batch_size,
        }, indent=2),
        mimetype="application/json",
        status_code=200,
    )
