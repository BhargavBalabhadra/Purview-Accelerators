"""
Single Purview API client. Wraps:
  - PyApacheAtlas (for entity bulk upload, relationships, classifications)
  - Raw REST via requests (for contacts, governance domains, collections,
    business metadata — anything PyApacheAtlas doesn't cover)

Auth, retry, and rate-limit policies live here. Repositories use this;
scenarios never touch it directly.
"""
import time
from functools import wraps
import requests
from azure.identity import DefaultAzureCredential
from pyapacheatlas.core import PurviewClient as PAAPClient

from platform.config import get_settings
from platform.exceptions import PurviewAPIError, ResourceNotFoundError
from platform.logging_setup import get_logger

log = get_logger(__name__)


def _retry_on_5xx(max_attempts: int = 3, backoff: float = 1.5):
    """Decorator: retry HTTP 5xx and 429 with exponential backoff."""
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            attempt = 0
            while True:
                try:
                    return fn(*args, **kwargs)
                except PurviewAPIError as e:
                    attempt += 1
                    if attempt >= max_attempts:
                        raise
                    if e.status_code and (e.status_code >= 500 or e.status_code == 429):
                        sleep = backoff ** attempt
                        log.warning(f"retry attempt={attempt} sleep={sleep:.1f}s err={e}")
                        time.sleep(sleep)
                        continue
                    raise
        return wrapper
    return deco


class PurviewClient:
    """Auth + transport. Singleton-ish via get_purview_client()."""

    def __init__(self, account_name: str):
        self.account_name = account_name
        self.endpoint = f"https://{account_name}.purview.azure.com"
        self._credential = DefaultAzureCredential()
        self._paap = PAAPClient(account_name=account_name, authentication=self._credential)
        log.info(f"PurviewClient initialised account={account_name}")

    @property
    def paap(self) -> PAAPClient:
        """PyApacheAtlas client — for operations it covers natively."""
        return self._paap

    def token(self) -> str:
        return self._credential.get_token("https://purview.azure.com/.default").token

    @_retry_on_5xx()
    def request(
        self,
        method: str,
        path: str,
        json_body: dict = None,
        params: dict = None,
    ) -> dict:
        """Raw REST call. Path is appended to the Purview endpoint."""
        url = f"{self.endpoint}{path}"
        headers = {
            "Authorization": f"Bearer {self.token()}",
            "Content-Type": "application/json",
        }
        try:
            resp = requests.request(
                method, url, headers=headers, json=json_body,
                params=params, timeout=30,
            )
        except requests.RequestException as e:
            raise PurviewAPIError(f"Network error calling {method} {path}: {e}")

        if resp.status_code == 404:
            raise ResourceNotFoundError(f"{method} {path} returned 404")

        if resp.status_code >= 400:
            raise PurviewAPIError(
                f"{method} {path} returned HTTP {resp.status_code}",
                status_code=resp.status_code,
                response_body=resp.text[:500],
            )

        if not resp.text:
            return {}
        try:
            return resp.json()
        except ValueError:
            return {"raw": resp.text}


_client: PurviewClient | None = None


def get_purview_client() -> PurviewClient:
    global _client
    if _client is None:
        _client = PurviewClient(get_settings().purview_account_name)
    return _client


def reset_client_for_testing() -> None:
    global _client
    _client = None
