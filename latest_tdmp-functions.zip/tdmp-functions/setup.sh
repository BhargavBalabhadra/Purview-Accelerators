#!/bin/bash
# TDMP Functions — first-time local setup
# Creates .venv, installs dependencies, runs unit tests
#
# Usage:  bash setup.sh
set -e

echo ""
echo "============================================"
echo "  TDMP Purview Platform — Local Setup"
echo "============================================"
echo ""

# ── Python check ──────────────────────────────────────────────────────────────
PYTHON=$(which python3 2>/dev/null || which python 2>/dev/null)
if [ -z "$PYTHON" ]; then
  echo "ERROR: python3 not found. Install Python 3.10 or newer."
  exit 1
fi
PY_VER=$($PYTHON --version 2>&1)
MAJOR=$($PYTHON -c "import sys; print(sys.version_info.major)")
MINOR=$($PYTHON -c "import sys; print(sys.version_info.minor)")
if [ "$MAJOR" -lt 3 ] || ([ "$MAJOR" -eq 3 ] && [ "$MINOR" -lt 10 ]); then
  echo "ERROR: Python 3.10+ required. Found: $PY_VER"
  exit 1
fi
echo "Python: $PY_VER"

# ── Azure Functions Core Tools check (warning only) ──────────────────────────
if ! command -v func &>/dev/null; then
  echo ""
  echo "WARNING: Azure Functions Core Tools not found."
  echo "  Install: npm install -g azure-functions-core-tools@4 --unsafe-perm true"
fi

# ── Virtual environment ──────────────────────────────────────────────────────
echo ""
echo "Creating .venv..."
$PYTHON -m venv .venv

echo "Installing dependencies..."
.venv/bin/pip install --upgrade pip --quiet
.venv/bin/pip install -r requirements.txt --quiet
.venv/bin/pip install pytest pytest-cov black isort --quiet

# ── Config check ─────────────────────────────────────────────────────────────
echo ""
echo "Checking local.settings.json placeholders..."
if grep -q "<your-" local.settings.json; then
  echo "  Found placeholder values — update before running:"
  grep "<your-" local.settings.json | sed 's/^/    /'
else
  echo "  Configured."
fi

# ── Run tests ────────────────────────────────────────────────────────────────
echo ""
echo "Running unit tests..."
PYTHONPATH=. .venv/bin/python -m pytest tests/unit -v --tb=short

echo ""
echo "============================================"
echo "  Setup complete."
echo ""
echo "  Next:"
echo "    1. Update local.settings.json"
echo "    2. func start"
echo "    3. Open .vscode/tdmp.http to trigger functions"
echo "============================================"
echo ""
