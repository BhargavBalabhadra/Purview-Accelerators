#!/bin/bash
# One-time blob container + folder structure setup
set -e
STORAGE_ACCOUNT="${STORAGE_ACCOUNT:-tdmpstorageaccount}"
CONTAINER="${CONTAINER:-purview-automation}"

az storage container create --name "$CONTAINER" --account-name "$STORAGE_ACCOUNT" --auth-mode login

for FOLDER in templates completed reports failed; do
  az storage blob upload --container-name "$CONTAINER" \
    --name "${FOLDER}/.keep" --data "" \
    --account-name "$STORAGE_ACCOUNT" --auth-mode login \
    --overwrite 2>/dev/null || true
  echo "Folder ready: $FOLDER/"
done

if [ -d "templates" ]; then
  for FILE in templates/*.xlsx; do
    [ -f "$FILE" ] || continue
    az storage blob upload --container-name "$CONTAINER" \
      --name "templates/$(basename $FILE)" --file "$FILE" \
      --account-name "$STORAGE_ACCOUNT" --auth-mode login --overwrite
  done
fi
echo "Done."
