#!/usr/bin/env python3
"""Called from azure-pipelines-trigger.yml Report stage."""
import json, sys, os

reports_dir = sys.argv[1] if len(sys.argv) > 1 else "."
files = sorted([
    os.path.join(reports_dir, f)
    for f in os.listdir(reports_dir)
    if f.endswith(".json")
])

if not files:
    print("No JSON reports found.")
    sys.exit(0)

print()
print("=" * 60)
print("  TDMP RUN SUMMARY")
print("=" * 60)

overall_fail = False
for fpath in files:
    try:
        d = json.load(open(fpath))
        s = d.get("summary", {})
        status = d.get("status", "UNKNOWN")
        marker = "OK  " if status == "COMPLETED" else "FAIL" if status == "FAILED" else "WARN"
        print(f"  [{marker}]  {d.get('scenario','?'):<28}"
              f"  run={d.get('run_id','?'):<10}"
              f"  ok={s.get('succeeded',0):<5}"
              f"  fail={s.get('failed',0):<5}"
              f"  parse_err={s.get('parse_errors',0):<5}"
              f"  {status}")
        for err in (d.get("runtime_errors") or [])[:3]:
            print(f"           -> {err}")
        for err in (d.get("parse_errors") or [])[:3]:
            print(f"           -> parse: {err}")
        if status in ("FAILED", "COMPLETED_WITH_ERRORS"):
            overall_fail = True
    except Exception as e:
        print(f"  [ERR ]  Could not parse {fpath}: {e}")

print("=" * 60)

if overall_fail:
    print("\nOne or more scenarios reported errors.")
    sys.exit(1)
print("\nAll scenarios completed successfully.")
sys.exit(0)
