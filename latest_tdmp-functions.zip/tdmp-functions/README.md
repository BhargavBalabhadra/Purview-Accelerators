# TDMP — Purview Automation Platform

Bulk metadata operations for Microsoft Purview, delivered as Azure Functions.
Excel-driven, queue-backed, ADO-orchestrated.

## What it does

Seven scenarios shipping today, with a plugin pattern that makes adding more take ~30 minutes:

| # | Scenario | Default template |
|---|---|---|
| 1 | Asset classification bulk apply | `asset_classifications.xlsx` |
| 2 | Asset labels (free-form tags) | `asset_labels.xlsx` |
| 3 | Asset description bulk upload | `asset_descriptions.xlsx` |
| 4 | Asset contacts (Owners / Experts) | `asset_contacts.xlsx` |
| 5 | CDE → Data Product mapping | `cde_to_product_mapping.xlsx` |
| 6 | Governance Domain bulk creation | `governance_domains.xlsx` |
| 7 | Asset → Data Product mapping | `asset_to_product_mapping.xlsx` |

## Architecture

Four-layer separation. Each layer talks only to the layer directly below it.

```
Scenarios   (one file per scenario, plugins via @register)
    │
    ▼
Domain      (repositories — pure Purview logic, fully unit-testable)
    │
    ▼
Adapters    (single PurviewClient — PyApacheAtlas + raw REST + retry)
    │
    ▼
Platform    (Excel I/O, blob I/O, queue, validation, logging, reporting)
```

The full layout:

```
tdmp-functions/
├── function_app.py                 4 functions: HTTP trigger, queue trigger,
│                                   dead-letter monitor, health check
│
├── scenarios/                      Plugin per scenario — implements ScenarioBase
│   ├── asset_classifications.py
│   ├── asset_labels.py
│   ├── asset_descriptions.py
│   ├── asset_contacts.py
│   ├── cde_to_product_mapping.py
│   ├── governance_domains.py
│   └── asset_to_product_mapping.py
│
├── domain/                         Domain repositories (pure Purview logic)
│   ├── entity_repository.py        Bulk upsert + cached GUID resolution
│   ├── relationship_repository.py  Atlas relationships
│   ├── classification_repository.py
│   ├── contacts_repository.py      Owners / Experts (read-modify-write)
│   ├── label_repository.py         Free-form tags
│   ├── collection_repository.py    Collection lookup
│   ├── data_product_repository.py
│   ├── domain_repository.py        Governance domains
│   └── cde_repository.py
│
├── adapters/
│   └── purview_client.py           Single API client (PAAP + REST + retry)
│
├── platform/                       Cross-cutting concerns
│   ├── exceptions.py               TDMPError hierarchy
│   ├── config.py                   Settings singleton from env vars
│   ├── logging_setup.py            Structured logging with run context
│   ├── validation.py               Declarative Schema + FieldSpec
│   ├── excel_io.py                 Parse + window
│   ├── blob_io.py                  Folder check, download, archive
│   ├── queue_io.py                 Enqueue + chain
│   ├── messages.py                 QueueMessage payload
│   ├── reporter.py                 Run report builder
│   ├── notifier.py                 Dead-letter alerts
│   ├── scenario_base.py            ScenarioBase + ScenarioContext
│   └── registry.py                 Plugin discovery
│
├── tests/
│   ├── unit/                       Unit tests (37 — fully mocked)
│   └── integration/                Integration tests (your env)
│
├── templates/                      Sample Excel files for all 7 scenarios
├── infra/                          Setup scripts
│
├── azure-pipelines.yml             Build & deploy (auto on push to main)
├── azure-pipelines-trigger.yml     Trigger only (manual run from ADO UI)
│
├── host.json                       Functions host config
├── local.settings.json             Local env vars
├── requirements.txt
├── .funcignore                     Slims deployment package
│
├── .vscode/                        Workspace settings, launch, tasks, REST client
├── tdmp-functions.code-workspace   Open this for one-click VS Code setup
├── setup.sh                        First-time local setup
└── README.md
```

## Quick start

### 1. Open in VS Code

```bash
code tdmp-functions/tdmp-functions.code-workspace
```

VS Code prompts to install recommended extensions — accept.

### 2. First-time setup

```bash
bash setup.sh
```

This creates `.venv`, installs everything from `requirements.txt`, and runs the unit tests.

### 3. Configure local settings

Edit `local.settings.json` and replace the `<your-...>` placeholders with your Purview account name, storage account name, and Key Vault URL.

### 4. Run locally

```bash
func start
```

Open `.vscode/tdmp.http` and click "Send Request" on any scenario — it will trigger the local function.

### 5. Run in Azure

Push to `main` and ADO build pipeline runs automatically (`azure-pipelines.yml`).

To trigger a deployed function from ADO, use the manual trigger pipeline (`azure-pipelines-trigger.yml`) and pick the scenario from the dropdown.

## Adding a new scenario

This is the platform's main payoff. Adding scenario #8 takes 5 steps:

```python
# scenarios/my_new_scenario.py

from platform.scenario_base import ScenarioBase, ScenarioContext
from platform.validation import Schema, FieldSpec
from platform.registry import register


@register
class MyNewScenarioScenario(ScenarioBase):
    name             = "my_new_scenario"
    default_template = "my_new_scenario.xlsx"
    schema = Schema(
        name="my_new_scenario",
        fields=[
            FieldSpec("qualified_name", required=True, type="str"),
            FieldSpec("some_email",     required=True, type="email"),
        ],
    )

    def run(self, rows: list[dict], ctx: ScenarioContext) -> dict:
        results = {"success": 0, "errors": []}
        for row in rows:
            try:
                guid = ctx.entity_repo.get_guid(row["qualified_name"], "azure_sql_table")
                # ... your domain operation here ...
                results["success"] += 1
            except Exception as e:
                results["errors"].append({"row": row["_excel_row"], "error": str(e)})
        return results
```

Then drop a sample template in `templates/my_new_scenario.xlsx`, write a unit test in `tests/unit/test_scenarios.py`, add the scenario name to the `azure-pipelines-trigger.yml` parameter list, and you're done. The platform handles validation, batching, queueing, retries, dead-lettering, reporting — all of it.

## Environment variables

| Variable | Required | Default |
|---|---|---|
| `PURVIEW_ACCOUNT_NAME` | yes | — |
| `STORAGE_ACCOUNT_NAME` | yes | — |
| `BLOB_CONTAINER_NAME` | yes | — |
| `QUEUE_NAME` | yes | — |
| `BLOB_TEMPLATE_FOLDER` | no | `templates` |
| `BLOB_REPORTS_FOLDER` | no | `reports` |
| `BLOB_FAILED_FOLDER` | no | `failed` |
| `BLOB_COMPLETED_FOLDER` | no | `completed` |
| `POISON_QUEUE_NAME` | no | `{queue}-poison` |
| `BATCH_SIZE` | no | `100` |
| `ALERT_EMAIL` | no | empty |
| `KEYVAULT_URL` | no | empty |
| `ACS_CONNECTION_STRING` | no | empty (logs only) |

## Permissions required (Managed Identity)

Assign these to the Function App's system-assigned identity:

| Resource | Role |
|---|---|
| Storage Account | Storage Blob Data Contributor |
| Storage Account | Storage Queue Data Contributor |
| Purview Account | Data Curator (per target collection) |
| Key Vault (if used) | Key Vault Secrets User |

## Testing

```bash
# Run all unit tests
.venv/bin/python -m pytest tests/unit -v

# With coverage
.venv/bin/python -m pytest tests/unit --cov=. --cov-report=term-missing
```

37 unit tests cover validation, excel parsing, registry, scenarios (with mocked repos), reporter, and message serialisation. Scenarios are tested without any real Purview connection by injecting `MagicMock` repositories — that's the layered architecture paying off.
