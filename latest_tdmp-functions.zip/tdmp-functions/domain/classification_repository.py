"""
Atlas classifications — applies tax/classification labels to entities.
"""
from platform.logging_setup import get_logger
from adapters.purview_client import PurviewClient

log = get_logger(__name__)


class ClassificationRepository:
    def __init__(self, client: PurviewClient):
        self._client = client

    def apply(
        self,
        type_name: str,
        qualified_name: str,
        classification_names: list[str],
    ) -> None:
        self._client.paap.classify_bulk_entities(
            typeName=type_name,
            qualifiedName=qualified_name,
            classificationNames=classification_names,
        )
        log.info(
            f"classifications applied qn={qualified_name} "
            f"count={len(classification_names)}"
        )
