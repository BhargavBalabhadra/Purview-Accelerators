"""
Atlas labels (free-form tags). Different from classifications:
labels are unstructured strings, classifications are taxonomy entries.
"""
from platform.logging_setup import get_logger
from adapters.purview_client import PurviewClient

log = get_logger(__name__)


class LabelRepository:
    def __init__(self, client: PurviewClient):
        self._client = client

    def add_labels(self, guid: str, labels: list[str]) -> None:
        """Adds labels to an entity. PUT replaces — so we GET, merge, PUT."""
        existing = self._client.request(
            "GET", f"/datamap/api/atlas/v2/entity/guid/{guid}/labels"
        )
        current = set(existing.get("labels", []) if isinstance(existing, dict) else existing or [])
        new_set = current | set(labels)

        self._client.request(
            "PUT",
            f"/datamap/api/atlas/v2/entity/guid/{guid}/labels",
            json_body=list(new_set),
        )
        log.info(
            f"labels added guid={guid[:8]} added={len(new_set - current)} "
            f"total={len(new_set)}"
        )
