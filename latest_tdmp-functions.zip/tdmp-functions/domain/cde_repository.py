"""
Critical Data Elements (CDEs). Custom Atlas type. Used for CDE-to-product mapping.
"""
from platform.logging_setup import get_logger
from domain.entity_repository import EntityRepository

log = get_logger(__name__)


CDE_TYPE_NAME = "CriticalDataElement"


class CDERepository:
    def __init__(self, entity_repo: EntityRepository):
        self._entity_repo = entity_repo

    def get_guid(self, qualified_name: str) -> str:
        return self._entity_repo.get_guid(qualified_name, CDE_TYPE_NAME)
