"""
Purview collections — used for pre-flight validation and to scope entity creation.
"""
from platform.logging_setup import get_logger
from adapters.purview_client import PurviewClient

log = get_logger(__name__)


class CollectionRepository:
    def __init__(self, client: PurviewClient):
        self._client = client
        self._cache: dict[str, dict] = {}

    def exists(self, friendly_name: str) -> bool:
        return self._lookup(friendly_name) is not None

    def get(self, friendly_name: str) -> dict | None:
        return self._lookup(friendly_name)

    def _lookup(self, friendly_name: str) -> dict | None:
        if friendly_name in self._cache:
            return self._cache[friendly_name]

        result = self._client.request(
            "GET", "/account/collections",
            params={"api-version": "2019-11-01-preview"},
        )
        for c in result.get("value", []):
            if c.get("friendlyName") == friendly_name:
                self._cache[friendly_name] = c
                return c

        self._cache[friendly_name] = None
        return None
