"""
Atlas relationships — used for data-product-to-asset, data-product-to-CDE,
and any other typed link between entities.
"""
from pyapacheatlas.core import AtlasRelationship

from platform.logging_setup import get_logger
from adapters.purview_client import PurviewClient

log = get_logger(__name__)


class RelationshipRepository:
    def __init__(self, client: PurviewClient):
        self._client = client

    def create(
        self,
        type_name: str,
        end1_guid: str, end1_type: str,
        end2_guid: str, end2_type: str,
    ) -> dict:
        rel = AtlasRelationship(
            typeName=type_name,
            end1={"guid": end1_guid, "typeName": end1_type},
            end2={"guid": end2_guid, "typeName": end2_type},
        )
        result = self._client.paap.upload_relationship(rel)
        log.info(
            f"relationship created type={type_name} "
            f"end1={end1_guid[:8]} end2={end2_guid[:8]}"
        )
        return result
