"""
Entity contacts (Owners / Experts).
Read-modify-write — fetches existing contacts, merges new email, writes back.
This avoids overwriting other owners that were set previously.
"""
from platform.logging_setup import get_logger
from adapters.purview_client import PurviewClient

log = get_logger(__name__)


VALID_CONTACT_TYPES = {"Expert", "Owner"}


class ContactsRepository:
    def __init__(self, client: PurviewClient):
        self._client = client

    def add_contact(
        self,
        guid: str,
        email_or_object_id: str,
        contact_type: str,
        info: str = "",
    ) -> None:
        """Adds a contact, preserving existing ones."""
        ct = contact_type.capitalize()
        if ct not in VALID_CONTACT_TYPES:
            raise ValueError(
                f"contact_type must be one of {VALID_CONTACT_TYPES}, got '{contact_type}'"
            )

        existing = self._client.request(
            "GET", f"/datamap/api/atlas/v2/entity/guid/{guid}"
        )
        contacts = existing.get("entity", {}).get("contacts", {})
        contact_list = contacts.get(ct, [])

        if email_or_object_id in {c.get("id", "") for c in contact_list}:
            log.info(f"contact already present guid={guid[:8]} email={email_or_object_id}")
            return

        contact_list.append({"id": email_or_object_id, "info": info})

        self._client.request(
            "POST",
            f"/datamap/api/atlas/v2/entity/guid/{guid}/contacts",
            json_body={"contacts": {**contacts, ct: contact_list}},
        )
        log.info(
            f"contact added guid={guid[:8]} type={ct} email={email_or_object_id}"
        )
