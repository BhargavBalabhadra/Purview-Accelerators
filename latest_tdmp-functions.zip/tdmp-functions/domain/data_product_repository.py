"""
Data Products — Purview unified-catalog construct. Created as custom Atlas
entities (typeName configurable per org).

Note: Purview's UC API path differs slightly from regular catalog REST.
This repository uses the Atlas REST surface, which works for entity-style
data products. If your org uses pure UC API, swap the implementation here
without touching scenarios.
"""
from pyapacheatlas.core import AtlasEntity

from platform.logging_setup import get_logger
from domain.entity_repository import EntityRepository

log = get_logger(__name__)


DATA_PRODUCT_TYPE_NAME = "DataProduct"  # override via your custom type if needed


class DataProductRepository:
    def __init__(self, entity_repo: EntityRepository):
        self._entity_repo = entity_repo

    def create(
        self,
        name: str,
        qualified_name: str,
        description: str,
        domain: str,
        status: str,
        steward_email: str,
    ) -> str:
        """Returns the assigned GUID."""
        entity = AtlasEntity(
            name=name,
            typeName=DATA_PRODUCT_TYPE_NAME,
            qualified_name=qualified_name,
            attributes={
                "description": description,
                "domain":      domain,
                "status":      status,
                "contacts": {
                    "Expert": [{"id": steward_email, "info": "Data Steward"}]
                },
            },
        )
        guid = self._entity_repo.upsert_one(entity)
        log.info(f"data product created name={name} guid={guid}")
        return guid

    def get_guid(self, qualified_name: str) -> str:
        return self._entity_repo.get_guid(qualified_name, DATA_PRODUCT_TYPE_NAME)
