"""
Governance Domains. In Purview's unified catalog, governance domains are
the top-level container for data products and CDEs.

Implemented via Atlas REST (the type may be 'GovernanceDomain' or your
org's custom equivalent).
"""
from pyapacheatlas.core import AtlasEntity

from platform.logging_setup import get_logger
from domain.entity_repository import EntityRepository

log = get_logger(__name__)


GOVERNANCE_DOMAIN_TYPE_NAME = "GovernanceDomain"


class DomainRepository:
    def __init__(self, entity_repo: EntityRepository):
        self._entity_repo = entity_repo

    def create(
        self,
        name: str,
        qualified_name: str,
        description: str,
        owner_email: str,
        parent_qualified_name: str = "",
    ) -> str:
        attrs = {
            "description": description,
            "contacts": {
                "Owner": [{"id": owner_email, "info": "Domain Owner"}]
            },
        }
        if parent_qualified_name:
            attrs["parentDomain"] = parent_qualified_name

        entity = AtlasEntity(
            name=name,
            typeName=GOVERNANCE_DOMAIN_TYPE_NAME,
            qualified_name=qualified_name,
            attributes=attrs,
        )
        guid = self._entity_repo.upsert_one(entity)
        log.info(f"governance domain created name={name} guid={guid}")
        return guid

    def get_guid(self, qualified_name: str) -> str:
        return self._entity_repo.get_guid(qualified_name, GOVERNANCE_DOMAIN_TYPE_NAME)
