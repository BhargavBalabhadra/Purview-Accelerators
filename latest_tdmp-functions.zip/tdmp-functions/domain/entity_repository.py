"""
Operations on Atlas entities (assets, data products, governance domains, CDEs).
Cached GUID resolution to avoid repeated lookups when scenarios reference
the same entity multiple times in one batch.
"""
from pyapacheatlas.core import AtlasEntity

from platform.exceptions import ResourceNotFoundError, PurviewAPIError
from platform.logging_setup import get_logger
from adapters.purview_client import PurviewClient

log = get_logger(__name__)


class EntityRepository:
    def __init__(self, client: PurviewClient):
        self._client = client
        self._guid_cache: dict[tuple[str, str], str] = {}

    def get_guid(self, qualified_name: str, type_name: str) -> str:
        """Resolves qualified_name → GUID, with in-memory caching."""
        key = (type_name, qualified_name)
        if key in self._guid_cache:
            return self._guid_cache[key]
        try:
            result = self._client.paap.get_entity(
                typeName=type_name,
                qualifiedName=qualified_name,
            )
            guid = result["entity"]["guid"]
            self._guid_cache[key] = guid
            return guid
        except Exception as e:
            raise ResourceNotFoundError(
                f"Entity not found: type='{type_name}' qualified_name='{qualified_name}': {e}"
            )

    def upsert_bulk(self, entities: list[AtlasEntity]) -> dict:
        """
        Bulk upsert. Splits into batches of 100 (Atlas API limit).
        Returns: {"success": int, "errors": [str]}
        """
        results = {"success": 0, "errors": []}
        batch_size = 100
        for i in range(0, len(entities), batch_size):
            chunk = entities[i: i + batch_size]
            try:
                self._client.paap.upload_entities(batch=chunk)
                results["success"] += len(chunk)
                log.info(f"upsert_bulk batch={i // batch_size + 1} count={len(chunk)}")
            except Exception as e:
                log.error(f"upsert_bulk batch={i // batch_size + 1} failed: {e}")
                results["errors"].append(str(e))
        return results

    def upsert_one(self, entity: AtlasEntity) -> str:
        """Single-entity upsert. Returns the assigned GUID."""
        result = self._client.paap.upload_entities(batch=[entity])
        guid_assignments = result.get("guidAssignments", {})
        if entity.qualifiedName in guid_assignments:
            return guid_assignments[entity.qualifiedName]
        mutated = result.get("mutatedEntities", {}).get("CREATE", [])
        if mutated:
            return mutated[0].get("guid", "")
        raise PurviewAPIError(
            f"Could not extract GUID from upload result: {result}"
        )
