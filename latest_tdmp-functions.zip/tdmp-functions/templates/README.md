# Excel Template Reference — 7 scenarios

Upload these to `<storage>/<container>/templates/` before running the corresponding ADO pipeline.

| # | Scenario | Template file | Required columns |
|---|---|---|---|
| 1 | Asset classifications | `asset_classifications.xlsx` | qualified_name, asset_type, classification_name |
| 2 | Asset labels (tags) | `asset_labels.xlsx` | qualified_name, asset_type, label |
| 3 | Asset descriptions | `asset_descriptions.xlsx` | qualified_name, asset_type, display_name, description |
| 4 | Asset contacts | `asset_contacts.xlsx` | qualified_name, asset_type, contact_email, contact_type |
| 5 | CDE → product mapping | `cde_to_product_mapping.xlsx` | cde_qualified_name, data_product_qualified_name |
| 6 | Governance domains | `governance_domains.xlsx` | name, qualified_name, description, owner_email |
| 7 | Asset → product mapping | `asset_to_product_mapping.xlsx` | asset_qualified_name, asset_type, data_product_qualified_name |

## Optional columns

- `user_description` (scenario 3) — falls back to `description` if blank
- `info` (scenario 4) — free-text annotation on the contact
- `relationship_type` (scenarios 5, 7) — defaults to standard relationship
- `parent_qualified_name` (scenario 6) — for nested domains

## Validation rules

The platform validates every column before the function ever touches Purview. Errors are returned with row numbers, e.g. `Row 7: 'contact_email' is not a valid email: 'not-an-email'`. Fix the Excel and re-run.

`contact_type` must be `Expert` or `Owner` exactly (case-sensitive). All `email` columns are regex-validated. `description` and `user_description` cap at 4000 characters.
